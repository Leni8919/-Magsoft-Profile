/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <QtGlobal>
#include <QtOpenGL>

#include "MeshDrawer.h"


MeshDrawer::MeshDrawer( unsigned int i_nbParts )
{
    colors.resize( i_nbParts + 1 );

    colors[0].r = 0.8;
    colors[0].g = 0.8;
    colors[0].b = 0.8;

    qsrand(4212);
    for( unsigned int i = 1; i < i_nbParts + 1; ++i )
    {
        colors[i].r = qrand() / (float)RAND_MAX;
        colors[i].g = qrand() / (float)RAND_MAX;
        colors[i].b = qrand() / (float)RAND_MAX;
    }
}


void MeshDrawer::drawDeciMesh(DeciMesh *p_dmesh, bool b_displayFaces,
                              bool b_displayEdges, bool b_displayVertices)
{
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);

    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(10.0f,1.0f);

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    if (b_displayFaces)
    {
        glColor3f( 0.8, 0.8, 0.8);

        for(DeciMesh::FaceIter fit = p_dmesh->faces_begin(); fit!=p_dmesh->faces_end(); ++fit)
        {
            const DeciMesh::FaceHandle f = fit.handle();
            if( p_dmesh->status(f).deleted() )
                continue;

            glBegin(GL_POLYGON);

            // Set the color of the face.
            if (p_dmesh->data(fit).b_marked)
                glColor3f(1.0f, 0.0f, 0.0f);
            else
                glColor3f( 0.8, 0.8, 0.8);

            DeciMesh::Normal n = p_dmesh->normal( fit.handle() );
            glNormal3f(n[0], n[1], n[2]);

            for(DeciMesh::FaceVertexIter fv_it = p_dmesh->fv_iter(f); fv_it; ++fv_it)
            {
                DeciMesh::VertexHandle v = fv_it.handle();
                DeciMesh::Point p = p_dmesh->point(v);
                glVertex3f(p[0], p[1], p[2]);
            }
            glEnd();
        }
    }

    glDisable(GL_POLYGON_OFFSET_FILL);

    glDisable(GL_LIGHTING);
    glDisable(GL_LIGHT0);
    glDisable(GL_NORMALIZE);

    if (b_displayEdges)
    {
      glLineWidth(1.0f);

      glBegin(GL_LINES);
      for(DeciMesh::EdgeIter e_it = p_dmesh->edges_begin();
          e_it != p_dmesh->edges_end(); ++e_it)
      {
          if (p_dmesh->status(e_it).deleted())
              continue;

          if (p_dmesh->data(e_it).b_marked)
              glColor3f(0.0f, 0.0f, 1.0f);
          else
              //continue;
              glColor3f(0.4f, 0.4f, 0.4f);

          DeciMesh::HalfedgeHandle h = p_dmesh->halfedge_handle( e_it, 0 );
          DeciMesh::Point p = p_dmesh->point( p_dmesh->from_vertex_handle( h ) );
          glVertex3f(p[0], p[1], p[2]);
          p = p_dmesh->point(p_dmesh->to_vertex_handle(h));
          glVertex3f(p[0], p[1], p[2]);
      }
      glEnd();
    }

    if (b_displayVertices)
    {
      glPointSize(5.0f);
      glBegin(GL_POINTS);
      for(DeciMesh::VertexIter vit = p_dmesh->vertices_begin();
          vit != p_dmesh->vertices_end(); ++vit)
      {
          if (p_dmesh->status(vit).deleted())
              continue;

          if (p_dmesh->data(vit).b_marked)
              glColor3f(1.0f, 0.0f, 0.0f);
          else
              glColor3f(0.4f, 0.4f, 0.4f);
          /*else
          {
              unsigned i_clusterId = p_dmesh->data(vit).i_clusterId;
              glColor3f(colors[i_clusterId].r, colors[i_clusterId].g, colors[i_clusterId].b);
          }*/

          DeciMesh::Point p = p_dmesh->point(vit.handle());
          glVertex3f(p[0], p[1], p[2]);
      }
      glEnd();
    }

    glDisable(GL_DEPTH_TEST);
}


void MeshDrawer::drawToPick(DeciMesh *p_bmesh)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3f( 0.8, 0.8, 0.8);

    for(DeciMesh::FaceIter fit = p_bmesh->faces_begin(); fit!=p_bmesh->faces_end(); ++fit)
    {
        const DeciMesh::FaceHandle f = fit.handle();
        if( p_bmesh->status(f).deleted() )
            continue;

        glLoadName(f.idx());
        glBegin(GL_POLYGON);
        for(DeciMesh::FaceVertexIter fv_it = p_bmesh->fv_iter(f); fv_it; ++fv_it)
        {
            DeciMesh::VertexHandle v = fv_it.handle();
            DeciMesh::Point p = p_bmesh->point(v);
            glVertex3f(p[0], p[1], p[2]);
        }
        glEnd();
    }
}
