/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <vector>

#include <QGLWidget>

#include "window.h"
#include "glwidget.h"
#include "Mesh/MeshHandler.h"
#include "MeshDrawer.h"

using OpenMesh::Vec3f;


class GLWidget : public QGLWidget
{
    Q_OBJECT

public:
    GLWidget( Window *parentWindow, MeshHandler *p_meshHandler,
              unsigned int i_nbParts);
    ~GLWidget();

    QSize minimumSizeHint() const;
    QSize sizeHint() const;
    double *getModelviewMatrix();
    double *getProjectionMatrix();
    unsigned *getFrameWidth();
    unsigned *getFrameHeight();

    void setSelMode();

    void displayNewMesh();

protected:
    void initializeGL();
    void resizeGL( int _w, int _h );
    void updateDisplayList(bool b_init);
    void paintGL();
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent( QMouseEvent* /* _event */ );
    void wheelEvent( QWheelEvent *_event );
    void set_scene_pos( const Vec3f &_cog, float _radius );
    void update_projection_matrix();
    void view_all();
    void translate( const Vec3f& _trans );
    void rotate( const Vec3f& _axis, float _angle );
    bool map_to_sphere( const QPoint& _v2D, Vec3f& _v3D );
    void keyPressEvent(QKeyEvent *e);
    void determineSelectedVertices(bool b_keepOldSelectedVertices);
    void findSelectedVertices(GLint hits, GLuint buff[],
                              bool b_keepOldSelectedVertices);

private:
    QColor qtGreen;
    QColor qtPurple;
    MeshHandler *p_meshHandler;
    MeshDrawer *p_meshDrawer;

    GLdouble *projection_matrix_;
    GLdouble *modelview_matrix_;
    unsigned *pi_frameWidth;
    unsigned *pi_frameHeight;

    set<DeciMesh::VertexHandle> selectedVertices;

    GLuint listId;

    QPoint           last_point_2D_;
    OpenMesh::Vec3f  last_point_3D_;
    bool             last_point_ok_;

    OpenMesh::Vec3f  center_;
    float            radius_;

    bool b_displayFaces;
    bool b_displayEdges;
    bool b_displayVertices;
    bool b_useVertexColor;
    bool b_displayOnePart;

    unsigned i_nbParts;

    bool isInSelMode;
    QPoint beginSelPoint;
    QPoint endSelPoint;
};

#endif
