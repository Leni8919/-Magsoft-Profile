/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <QtGui>
#include <QHBoxLayout>
#include <QMutex>

#include "glwidget.h"
#include "window.h"
#include "Mesh/MeshHandler.h"


Window::Window(MeshHandler *p_handler)
    : p_handler(p_handler), b_operationRuning(false)
{
    p_waitToContinue = p_handler->p_waitToContinue;

    connect(p_handler->myMeshDecimater, SIGNAL(hasChangedMesh()),
            this, SLOT(meshesModified()));
    connect(p_handler->myMeshCompressor, SIGNAL(hasChangedMesh()),
            this, SLOT(meshesModified()));
    connect(p_handler->myMeshDecompressor, SIGNAL(hasChangedMesh()),
            this, SLOT(meshesModified()));

    glWidget = new GLWidget(this, p_handler, 3000);


    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addWidget(glWidget);
    setLayout(mainLayout);

    setWindowTitle( tr( "Random accessible and progressive compression" ) );
}


Window::~Window()
{
    delete glWidget;
}


void Window::meshesModified()
{
    glWidget->displayNewMesh();
}


void Window::keyPressEvent(QKeyEvent *e)
{
    switch (e->key())
    {
    case Qt::Key_F1:
        if (p_handler->isInCompressionMode())
            p_handler->decimate();
        else
            glWidget->setSelMode();
        break;
    case Qt::Key_F2:
        if (p_handler->isInCompressionMode())
            p_handler->compress();
        break;
    case Qt::Key_N:
        p_waitToContinue->wakeAll();
        break;
    case Qt::Key_Escape:
        close();
        break;
    default:
        QWidget::keyPressEvent(e);
        break;
    }
}

