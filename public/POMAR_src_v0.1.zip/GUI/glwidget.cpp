/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "glwidget.h"

#include <QtGui>
#include <QtOpenGL>
#include <QInputDialog>
#include <GL/glut.h>

#include <math.h>

#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif

const double TRACKBALL_RADIUS = 0.6;


GLWidget::GLWidget( Window *parentWindow, MeshHandler *p_meshHandler,
                    unsigned int i_nbParts)
    : QGLWidget( QGLFormat( QGL::SampleBuffers ), parentWindow ),
      p_meshHandler(p_meshHandler),
      b_displayFaces( true ), b_displayEdges( true ), b_displayVertices( false ),
      b_useVertexColor( true ), b_displayOnePart(false),
      i_nbParts(i_nbParts), isInSelMode(false)
{
    Vec3f bbMin = p_meshHandler->getDeciMesh()->bbMin;
    Vec3f bbMax = p_meshHandler->getDeciMesh()->bbMax;

    center_ = ( bbMin + bbMax ) * 0.5;
    radius_ = ( bbMin - bbMax ).norm() * 0.5;

    qtGreen = QColor::fromCmykF(0.40, 0.0, 1.0, 0.0);
    qtPurple = QColor::fromCmykF(0.39, 0.39, 0.0, 0.0);

    setFocusPolicy( Qt::StrongFocus );

    projection_matrix_ = new GLdouble[16];
    modelview_matrix_ = new GLdouble[16];
    pi_frameWidth = new unsigned;
    pi_frameHeight = new unsigned;

    p_meshDrawer = new MeshDrawer( i_nbParts );
}


GLWidget::~GLWidget()
{
    delete[] projection_matrix_;
    delete[] modelview_matrix_;
    delete pi_frameWidth;
    delete pi_frameHeight;
}


QSize GLWidget::minimumSizeHint() const
{
    return QSize(50, 50);
}


QSize GLWidget::sizeHint() const
{
    return QSize(600, 600);
}


void GLWidget::initializeGL()
{
    // OpenGL state
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glDisable( GL_DITHER );
    glEnable( GL_DEPTH_TEST );

    // Lighting
    float position[] = {1,1,5,0}; // directional behind the viewer
    glLightfv(GL_LIGHT0,GL_POSITION,position);
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);

    // Fog
    GLfloat fogColor[4] = { 0.3, 0.3, 0.4, 1.0 };
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogfv(GL_FOG_COLOR, fogColor);
    glFogf(GL_FOG_DENSITY, 0.35);
    glHint(GL_FOG_HINT, GL_DONT_CARE);
    glFogf(GL_FOG_START, 5.0f);
    glFogf(GL_FOG_END, 25.0f);

    // scene pos and size
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glGetDoublev(GL_MODELVIEW_MATRIX, modelview_matrix_);
    set_scene_pos( center_, radius_ );

    glEnable(GL_COLOR_MATERIAL);
    glShadeModel(GL_SMOOTH);

    updateDisplayList(true);
}


void GLWidget::resizeGL( int _w, int _h )
{
  *pi_frameWidth = _w;
  *pi_frameHeight = _h;
  update_projection_matrix();
  glViewport(0, 0, _w, _h);
  updateGL();
}


void GLWidget::displayNewMesh()
{
    updateDisplayList(false);
    update();
}

void GLWidget::updateDisplayList(bool b_init)
{
    printf("Start to update the display list.\n");

    if (!b_init)
        glDeleteLists(listId, 1);

    listId = glGenLists(1);

    glNewList(listId, GL_COMPILE);

    // Draw the mesh.
    DeciMesh *p_dmesh = p_meshHandler->getDeciMesh();
    p_meshDrawer->drawDeciMesh(p_dmesh, b_displayFaces, b_displayEdges,
                               b_displayVertices);

    glEndList();
}


void GLWidget::paintGL()
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glMatrixMode( GL_PROJECTION );
    glLoadMatrixd( projection_matrix_ );
    glMatrixMode( GL_MODELVIEW );
    glLoadMatrixd( modelview_matrix_ );

    glCallList(listId);

    if (isInSelMode)
    {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glOrtho(0, width(), height(), 0, -1, 10);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        glClear(GL_DEPTH_BUFFER_BIT);

        glBegin(GL_LINE_LOOP);
            glColor3f(1.0f, 0.0f, 0.0);
            glVertex2f(beginSelPoint.x(), beginSelPoint.y());
            glVertex2f(endSelPoint.x(), beginSelPoint.y());
            glVertex2f(endSelPoint.x(), endSelPoint.y());
            glVertex2f(beginSelPoint.x(), endSelPoint.y());
        glEnd();

        // Making sure we can render 3d again
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
    }
}


void GLWidget::mousePressEvent( QMouseEvent *event )
{
    if (!isInSelMode)
        last_point_ok_ = map_to_sphere( last_point_2D_ = event->pos(),
                                        last_point_3D_ );
    else
    {
        isInSelMode = true;
        beginSelPoint = event->pos();
    }
}


void GLWidget::mouseMoveEvent( QMouseEvent *_event )
{
    QPoint newPoint2D = _event->pos();

    if (isInSelMode)
    {
        endSelPoint = newPoint2D;
    }
    else
    {
        // Left button: rotate around center_
        // Middle button: translate object
        // Left & middle button: zoom in/out

        float  value_y;
        Vec3f  newPoint3D;
        bool   newPoint_hitSphere = map_to_sphere( newPoint2D, newPoint3D );

        float dx = newPoint2D.x() - last_point_2D_.x();
        float dy = newPoint2D.y() - last_point_2D_.y();

        float w  = width();
        float h  = height();


        // move in z direction
        if ( ( _event->buttons() == ( Qt::MidButton ) ) ||
                (_event->buttons() == Qt::LeftButton && _event->modifiers() == Qt::ControlModifier))
        {
          value_y = radius_ * dy * 3.0 / h;
          translate(Vec3f(0.0, 0.0, value_y));
        }


        // move in x,y direction
        else if ( (_event->buttons() == Qt::RightButton) ||
                  (_event->buttons() == Qt::LeftButton && _event->modifiers() == Qt::AltModifier) )
        {
          float z = - (modelview_matrix_[ 2]*center_[0] +
                       modelview_matrix_[ 6]*center_[1] +
                       modelview_matrix_[10]*center_[2] +
                       modelview_matrix_[14]) /
                      (modelview_matrix_[ 3]*center_[0] +
                       modelview_matrix_[ 7]*center_[1] +
                       modelview_matrix_[11]*center_[2] +
                       modelview_matrix_[15]);

          float aspect     = w / h;
          float near_plane = 0.01 * radius_;
          float f_fovy = 45;
          float top        = tan( f_fovy /2.0f*M_PI/180.0f) * near_plane;
          float right      = aspect*top;

          translate(Vec3f( 2.0*dx/w*right/near_plane*z,
                          -2.0*dy/h*top/near_plane*z,
                           0.0f));
        }

        // rotate
        else if ( _event->buttons() == Qt::LeftButton)
        {
          if (last_point_ok_)
          {
            if ( (newPoint_hitSphere = map_to_sphere(newPoint2D, newPoint3D)) )
            {
              Vec3f axis = last_point_3D_ % newPoint3D;
                    if (axis.sqrnorm() < 1e-7) {
                        axis = Vec3f(1,0,0);
                    } else {
                        axis.normalize();
                    }
                    // find the amount of rotation
                    Vec3f d = last_point_3D_ - newPoint3D;
                    float t = 0.5*d.norm() / TRACKBALL_RADIUS;
                    if (t<-1.0) t=-1.0;
                    else if (t>1.0) t=1.0;
                    float phi = 2.0 * asin(t);
                    float  angle =  phi * 180.0 / M_PI;
                rotate( axis, angle );
              }
            }
          }


        // remember this point
        last_point_2D_ = newPoint2D;
        last_point_3D_ = newPoint3D;
        last_point_ok_ = newPoint_hitSphere;
    }

    // Render the 3D scene.
    update();
}


void GLWidget::mouseReleaseEvent(QMouseEvent* _event)
{
    if (isInSelMode)
    {
        bool b_keepOldSelectedVertices =
            _event->button() == Qt::RightButton ? true : false;
        endSelPoint = _event->pos();
        isInSelMode = false;
        determineSelectedVertices(b_keepOldSelectedVertices);
    }
    else
        last_point_ok_ = false;
}


void GLWidget::wheelEvent( QWheelEvent* _event )
{
    float d = -(float)_event->delta() / 120.0 * 0.2 * radius_;
    translate(Vec3f(0.0, 0.0, d));
    updateGL();
    _event->accept();
}


void GLWidget::set_scene_pos( const Vec3f &_cog, float _radius )
{
  center_ = _cog;
  radius_ = _radius;
  glFogf( GL_FOG_START,      1.5*_radius );
  glFogf( GL_FOG_END,        3.0*_radius );

  update_projection_matrix();
  view_all();
}


void GLWidget::update_projection_matrix()
{
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective(45.0, (GLfloat) width() / (GLfloat) height(),
                 0.01*radius_, 100.0*radius_);
    glGetDoublev( GL_PROJECTION_MATRIX, projection_matrix_);
    glMatrixMode( GL_MODELVIEW );
}


void GLWidget::view_all()
{
  translate( Vec3f( -( modelview_matrix_[0] * center_[0] +
                       modelview_matrix_[4] * center_[1] +
                       modelview_matrix_[8] * center_[2] +
                       modelview_matrix_[12] ),
                    -( modelview_matrix_[1] * center_[0] +
                       modelview_matrix_[5] * center_[1] +
                       modelview_matrix_[9] * center_[2] +
                       modelview_matrix_[13] ),
                    -( modelview_matrix_[2] * center_[0] +
                       modelview_matrix_[6] * center_[1] +
                       modelview_matrix_[10] * center_[2] +
                       modelview_matrix_[14] +
                       3.0 * radius_ ) ) );
}


void GLWidget::translate( const Vec3f& _trans )
{
    glLoadIdentity();
    glTranslated( _trans[0], _trans[1], _trans[2] );
    glMultMatrixd( modelview_matrix_ );
    glGetDoublev( GL_MODELVIEW_MATRIX, modelview_matrix_);
}


void GLWidget::rotate( const Vec3f& _axis, float _angle )
{
    // Rotate around center center_, axis _axis, by angle _angle
    // Update modelview_matrix_

    Vec3f t( modelview_matrix_[0] * center_[0] +
             modelview_matrix_[4] * center_[1] +
             modelview_matrix_[8] * center_[2] +
             modelview_matrix_[12],
             modelview_matrix_[1] * center_[0] +
             modelview_matrix_[5] * center_[1] +
             modelview_matrix_[9] * center_[2] +
             modelview_matrix_[13],
             modelview_matrix_[2] * center_[0] +
             modelview_matrix_[6] * center_[1] +
             modelview_matrix_[10] * center_[2] +
             modelview_matrix_[14] );

    glLoadIdentity();
    glTranslatef(t[0], t[1], t[2]);
    glRotated( _angle, _axis[0], _axis[1], _axis[2]);
    glTranslatef(-t[0], -t[1], -t[2]);
    glMultMatrixd(modelview_matrix_);
    glGetDoublev(GL_MODELVIEW_MATRIX, modelview_matrix_);
}


bool GLWidget::map_to_sphere( const QPoint& _v2D, Vec3f& _v3D )
{
    // This is actually doing the Sphere/Hyperbolic sheet hybrid thing,
    // based on Ken Shoemake's ArcBall in Graphics Gems IV, 1993.
    double x =  (2.0*_v2D.x() - width())/width();
    double y = -(2.0*_v2D.y() - height())/height();
    double xval = x;
    double yval = y;
    double x2y2 = xval*xval + yval*yval;

    const double rsqr = TRACKBALL_RADIUS * TRACKBALL_RADIUS;
    _v3D[0] = xval;
    _v3D[1] = yval;
    if( x2y2 < 0.5*rsqr )
        _v3D[2] = sqrt( rsqr - x2y2 );
    else
        _v3D[2] = 0.5 * rsqr / sqrt( x2y2 );

    return true;
}


void GLWidget::keyPressEvent(QKeyEvent *e)
{
    switch (e->key())
    {
    case Qt::Key_F:
        b_displayFaces = !b_displayFaces;
        updateDisplayList(false);
        update();
        break;
    case Qt::Key_E:
        b_displayEdges = !b_displayEdges;
        updateDisplayList(false);
        update();
        break;
    case Qt::Key_V:
        b_displayVertices = !b_displayVertices;
        updateDisplayList(false);
        update();
        break;
    case Qt::Key_C:
        b_useVertexColor = !b_useVertexColor;
        updateDisplayList(false);
        update();
        break;
    case Qt::Key_K:
        // saveCameraPos();
        updateDisplayList(false);
        update();
        break;
    case Qt::Key_L:
        // loadCameraPos();
        updateDisplayList(false);
        update();
        break;
    default:
        QWidget::keyPressEvent(e);
        break;
    }
}


void GLWidget::setSelMode()
{
    isInSelMode = true;
}


double *GLWidget::getModelviewMatrix()
{
    return modelview_matrix_;
}


double *GLWidget::getProjectionMatrix()
{
    return projection_matrix_;
}

unsigned *GLWidget::getFrameWidth()
{
    return pi_frameWidth;
}

unsigned *GLWidget::getFrameHeight()
{
    return pi_frameHeight;
}


void GLWidget::determineSelectedVertices(bool b_keepOldSelectedVertices)
{
    DeciMesh *p_bmesh = p_meshHandler->getBaseMesh();
    unsigned i_nbFaces = p_bmesh->n_faces();
    GLuint buff[i_nbFaces];
    memset(buff, 0, i_nbFaces * sizeof(GLuint));
    GLint view[4];

    // This choose the buffer where store the values for the selection data
    glSelectBuffer(i_nbFaces, buff);

    // This retrieve info about the viewport
    glGetIntegerv(GL_VIEWPORT, view);

    // Switching in selecton mode
    glRenderMode(GL_SELECT);

    // Clearing the name's stack
    // This stack contains all the info about the objects
    glInitNames();

    // Now fill the stack with one element (or glLoadName will generate an error)
    glPushName(-1);

    // Now modify the vieving volume, restricting selection area around the cursor
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();

    // restrict the rectangle.
    QPoint center((beginSelPoint.x() + endSelPoint.x()) / 2,
                  height() - (beginSelPoint.y() + endSelPoint.y()) / 2);
    QPoint size(abs(beginSelPoint.x() - endSelPoint.x()),
                abs(beginSelPoint.y() - endSelPoint.y()));

    gluPickMatrix(center.x(), center.y(), size.x(), size.y(), view);
    gluPerspective(45.0, (GLfloat)width() / (GLfloat)height(),
                   0.01*radius_, 100.0*radius_);

    // Draw the objects onto the screen
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadMatrixd(modelview_matrix_);

    // draw only the names in the stack, and fill the array
    p_meshDrawer->drawToPick(p_bmesh);

    // Get number of objects drawed in that area
    // and return to render mode
    GLint hits = glRenderMode(GL_RENDER);
    cout << "Nb hits: " << hits << endl;

    findSelectedVertices(hits, buff, b_keepOldSelectedVertices);

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}


void GLWidget::findSelectedVertices(GLint hits, GLuint buff[],
                                    bool b_keepOldSelectedVertices)
{
    // Build the set of the hit faces.
    // Find the face that has the minumin depth value.
    DeciMesh *p_bmesh = p_meshHandler->getBaseMesh();
    set<DeciMesh::FaceHandle> hitFaces;
    DeciMesh::FaceHandle fh_minZBuffer;
    unsigned i_minZBuffer = 0;
    for (int i = 0; i < hits; ++i)
    {
        const DeciMesh::FaceHandle fh(buff[4 * i + 3]);
        const unsigned i_zBuffer = buff[4 * i + 1];
        if (i == 0 || i_zBuffer < i_minZBuffer)
        {
            fh_minZBuffer = fh;
            i_minZBuffer = i_zBuffer;
        }
        hitFaces.insert(fh);
    }

    // Find the faces linked to the face with the minimum depth value.
    set<DeciMesh::FaceHandle> selectedFaces;
    queue<DeciMesh::FaceHandle> fh_FIFO;
    fh_FIFO.push(fh_minZBuffer);
    while (!fh_FIFO.empty())
    {
        const DeciMesh::FaceHandle fh = fh_FIFO.front();
        fh_FIFO.pop();

        const set<DeciMesh::FaceHandle>::iterator fhIt = hitFaces.find(fh);
        if (fhIt != hitFaces.end())
        {
            hitFaces.erase(fhIt);
            selectedFaces.insert(fh);
            for (DeciMesh::ConstFaceFaceIter ff_it = p_bmesh->ff_iter(fh);
                 ff_it; ++ff_it)
                fh_FIFO.push(ff_it);
        }
    }

    // Reset the marking of the vertices.
    for (DeciMesh::ConstVertexIter v_it = p_bmesh->vertices_begin();
         v_it != p_bmesh->vertices_end(); ++v_it)
        p_bmesh->data(v_it).b_marked = false;

    // Find the selected vertices.
    if (!b_keepOldSelectedVertices)
        selectedVertices.clear();
    for (set<DeciMesh::FaceHandle>::iterator fh_it = selectedFaces.begin();
         fh_it != selectedFaces.end(); ++fh_it)
        for (DeciMesh::ConstFaceVertexIter fv_it = p_bmesh->fv_iter(*fh_it);
             fv_it; ++fv_it)
        {
            bool b_selectedVertex = true;
            for (DeciMesh::ConstVertexFaceIter vf_it = p_bmesh->vf_iter(fv_it);
                 vf_it; ++vf_it)
                if (selectedFaces.find(vf_it) == selectedFaces.end())
                {
                    b_selectedVertex = false;
                    break;
                }

            if (b_selectedVertex)
            {
                p_bmesh->data(fv_it).b_marked = true;
                selectedVertices.insert(fv_it);
            }
        }

    p_meshHandler->decompress(selectedVertices);
}
