/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <iomanip>

#include "meshDecimater.hpp"

#include <QMutex>


void MeshDecimater::computeCollapseCosts()
{
    std::cout << "Compute all halfedge collapse costs.\n";

    while (!collapseCandidates.empty())
        collapseCandidates.pop();

    class CollapseCostComputer : public QRunnable
    {
    public:
        CollapseCostComputer(DeciMesh *p_dmesh,
                             DeciMesh::ConstHalfedgeIter &hIt,
                             priority_queue<CollapseCandidate, vector<CollapseCandidate> > &collapseCandidates,
                             QMutex &hItMutex,
                             QMutex &collapseCandidatesMutex)
            : p_dmesh(p_dmesh), hIt(hIt), collapseCandidates(collapseCandidates),
              hItMutex(hItMutex), collapseCandidatesMutex(collapseCandidatesMutex)
        {}

        /**
          * Test if an halfedge collapse is ok.
          * If yes, compute its cost and store it in the mesh data.
          * This cost is actually the volume between the patch surface before the collapse
          * and the patch surface after.
          */
        void run()
        {
            while (1)
            {
                hItMutex.lock();
                DeciMesh::HalfedgeHandle heh;
                while (1)
                {
                    if (hIt == p_dmesh->halfedges_end())
                    {
                        hItMutex.unlock();
                        return;
                    }

                    heh = hIt.handle();

                    ++hIt;
                    if (!p_dmesh->status(p_dmesh->edge_handle(heh)).deleted())
                        break;
                }
                hItMutex.unlock();

                if (!p_dmesh->is_collapse_ok(heh)) // Test if this halfedge can be collapsed.
                {
                    p_dmesh->data(heh).b_collapseOk = false;
                    continue;
                }

//#define VOLUME_METRIC

                DeciMesh::VertexHandle vh_from = p_dmesh->from_vertex_handle(heh);
                DeciMesh::VertexHandle vh_to = p_dmesh->to_vertex_handle(heh);
                unsigned i_nbFaces = p_dmesh->valence(vh_from);
                DeciMesh::VertexHandle faceVertices[i_nbFaces][3];
                Vec3f faceNormals[i_nbFaces];
#ifdef VOLUME_METRIC
                float f_stream = 0;

                bool b_collapseForbiden = false;
                for (DeciMesh::ConstVertexEdgeIter ve_it = p_dmesh->cve_iter(vh_from);
                     ve_it; ++ve_it)
                {
                    Vec3f n[] = {p_dmesh->normal(p_dmesh->face_handle(p_dmesh->halfedge_handle(ve_it, 0))),
                                 p_dmesh->normal(p_dmesh->face_handle(p_dmesh->halfedge_handle(ve_it, 1)))};
                    if ((n[0] | n[1]) < 0.4)
                    {
                        p_dmesh->data(heh).b_collapseOk = false;
                        p_dmesh->data(ve_it).b_marked = true;
                        b_collapseForbiden = true;
                        break;
                    }
                }

                if (b_collapseForbiden)
                    continue;
#endif

                DeciMesh::HalfedgeHandle hehIt = heh;
                for (unsigned i = 0; i < i_nbFaces; ++i)
                {
                    DeciMesh::HalfedgeHandle hehIt2 = hehIt;
                    for (unsigned j = 0; j < 3; ++j)
                    {
                        faceVertices[i][j] = p_dmesh->to_vertex_handle(hehIt2);
                        hehIt2 = p_dmesh->next_halfedge_handle(hehIt2);
                    }

                    // Compute the face normal.
                    //faceNormals[i] = p_dmesh->calc_face_normal(faceVertices[i]);
                    const DeciMesh::FaceHandle fh = p_dmesh->face_handle(hehIt);
                    faceNormals[i] = p_dmesh->normal(fh);
#ifdef VOLUME_METRIC
                    f_stream += p_dmesh->point(faceVertices[i][0]) |
                                faceNormals[i] * p_dmesh->calc_face_surface(fh);
#endif
                    hehIt = p_dmesh->prev_halfedge_handle(hehIt);
                    hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
                }

                for (unsigned i = 1; i < i_nbFaces - 1; ++i)
                {
                    // In each face replace vh_from by vh_to.
                    faceVertices[i][2] = vh_to;

                    // Compute the face normal.
                    Vec3f normal = p_dmesh->calc_face_normal(faceVertices[i]);

                    if (!areNormalOk(normal, faceNormals[i]))
                    {
                        p_dmesh->data(heh).b_collapseOk = false;
                        continue;
                    }
#ifdef VOLUME_METRIC
                    else
                        f_stream -= p_dmesh->point(faceVertices[i][0]) |
                                    normal * p_dmesh->calc_face_surface(faceVertices[i]);
#endif
                }

                // Find v2 if it exists.
                DeciMesh::VertexHandle v2;
                float f_maxLen = 0;
                for (DeciMesh::ConstVertexVertexIter vv_it = p_dmesh->cvv_iter(vh_from);
                     vv_it; ++vv_it)
                {
                    float f_len = (p_dmesh->point(vh_to) - p_dmesh->point(vv_it)).length();
                    if (vv_it.handle() != vh_to
                        && !p_dmesh->areVerticesConnected(vv_it, vh_to)
                        && (!p_dmesh->is_valid_handle(v2) || (f_len > f_maxLen)))
                    {
                        v2 = vv_it;
                        f_maxLen = f_len;
                    }
                }

                if (!p_dmesh->is_valid_handle(v2))
                {
                    p_dmesh->data(heh).b_collapseOk = false;
                    continue;
                }

                // Store the computed cost.
                //float f_cost = f_maxLen;
#ifdef VOLUME_METRIC
                float f_cost = fabs(f_stream / 3);
#else
                float f_cost = f_maxLen;
#endif
                collapseCandidatesMutex.lock();
                collapseCandidates.push(CollapseCandidate(heh, f_cost, v2));
                collapseCandidatesMutex.unlock();
                p_dmesh->data(heh).b_collapseOk = true;
            }
        }


        /**
          * Check that the normal condition of a collapse or a removal is ok.
          * @param n1, the first normal
          * @param n2, the second normal
          * @return true if the normal are ok else false.
          */
        bool areNormalOk(Vec3f n1, Vec3f n2)
        {
            if (n1 == Vec3f(0,0,0)
                || n2 == Vec3f(0,0,0)
                || (n1 | n2) > 0.7)
                return true;
            else
                return false;
        }

        DeciMesh *p_dmesh;

        DeciMesh::ConstHalfedgeIter &hIt;
        priority_queue<CollapseCandidate, vector<CollapseCandidate> > &collapseCandidates;

        QMutex &hItMutex;
        QMutex &collapseCandidatesMutex;
    };

    QMutex hItMutex;
    QMutex collapseCandidatesMutex;
    DeciMesh::ConstHalfedgeIter hIt = p_dmesh->halfedges_begin();

    CollapseCostComputer *myComputers[i_nbThreads];
    for (unsigned i = 0; i < i_nbThreads; ++i)
        myComputers[i] = new CollapseCostComputer(p_dmesh, hIt, collapseCandidates,
                                                  hItMutex, collapseCandidatesMutex);

    for (unsigned i = 0; i < i_nbThreads; ++i)
        myThreadPool.tryStart(myComputers[i]);

    myThreadPool.waitForDone();
}



