/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef MESHDECIMATERTRAITS_HPP
#define MESHDECIMATERTRAITS_HPP

#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

using namespace OpenMesh;
using namespace std;

#include <list>
#include <set>
#include <deque>
#include <list>

#define NB_EDGE_GOUPS 16

struct PerformedOperation
{
    VertexHandle v1;
    VertexHandle v2;
    VertexHandle vr;

    VertexHandle vhPivotL;
    VertexHandle vhPivotR;
};


struct MeshDecimaterTraits : public DefaultTraits
{
    VertexAttributes(Attributes::Status);
    FaceAttributes(Attributes::Status);
    EdgeAttributes(Attributes::Status);
    HalfedgeAttributes(Attributes::Status);

    VertexTraits
    {
        VertexT() : b_marked(false), i_clusterId(0) {}

        bool b_marked;
        unsigned i_clusterId;
        bool b_conquered;
    };

    HalfedgeTraits
    {
        HalfedgeT() {}

        bool b_collapseOk;
        bool b_dontCount;
    };

    EdgeTraits
    {
        EdgeT() : b_marked(false) {}
        bool b_marked;
    };

    FaceTraits
    {
        FaceT() : b_marked(false) {}
        bool b_marked;
    };
};


typedef multimap<VertexHandle, PerformedOperation> PerformedOperationMap;
typedef pair<VertexHandle, PerformedOperation> PerformedOperationPair;


class DeciMesh : public TriMesh_ArrayKernelT<MeshDecimaterTraits>
{
public:
    DeciMesh() {}

    float f_avgEdgeLen;

    unsigned i_nbQuantBits;
    Vec3f bbMin;
    Vec3f bbMax;
    float f_quantStep;

    unsigned i_nbVerticesBaseMesh;
    unsigned i_nbClusters;
    unsigned i_nbGlobalLOD;
    unsigned i_nbClusteredLOD;

    deque<PerformedOperationMap> performedOperations;

    deque<unsigned> clusterSizes;

    deque<DeciMesh::HalfedgeHandle> clusterSeedHeh;

    void updateBoundingBox();
    Vec3i floatPosToInt(Point p) const;
    Point intPosToFloat(Vec3i p) const;
    Vec3i getQuantPos(const VertexHandle vh) const;
    void quantizeVertexPositions();
    void numberClusters();

    void markEdgesToNotCount(unsigned i_clusterId, const PerformedOperation &op);
    void markEdgeHalfedgesToNotCount(unsigned i_clusterId, HalfedgeHandle heh);

    float maxNeighborEdgesLength(const VertexHandle vh);

    bool is_collapse_ok(HalfedgeHandle v0v1) const;
    void collapse(HalfedgeHandle h);

    Normal calc_face_normal(FaceHandle fh) const
    {
        ConstFaceVertexIter fv_it = cfv_iter(fh);
        const DeciMesh::Point p[] = {point(fv_it),
                                     point(++fv_it),
                                     point(++fv_it)};

        return ((p[2] - p[1]) % (p[0] - p[1])).normalize_cond();
    }

    Normal calc_face_normal(VertexHandle polygonVertices[]) const
    {
        const DeciMesh::Point p[] = {point(polygonVertices[0]),
                                     point(polygonVertices[1]),
                                     point(polygonVertices[2])};

        return ((p[2] - p[1]) % (p[0] - p[1])).normalize_cond();
    }

    float calc_face_surface(FaceHandle fh) const;
    float calc_face_surface(VertexHandle polygonVertices[]) const;

    bool areVerticesConnected(VertexHandle v1, VertexHandle v2) const
    {
        for (ConstVertexVertexIter vv_it = cvv_iter(v1); vv_it; ++vv_it)
            if (vv_it.handle() == v2)
                return true;
        return false;
    }
};


#endif // MESHDECIMATERTRAITS_HPP
