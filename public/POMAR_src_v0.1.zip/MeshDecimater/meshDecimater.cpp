/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/IO/reader/OFFReader.hh>
#include <OpenMesh/Core/IO/writer/OFFWriter.hh>

#include <queue>
#include <algorithm>
#include <iomanip>

#include <QMutex>

#include "meshDecimater.hpp"



void MeshDecimater::setData(DeciMesh *p_dmesh)
{
    this->p_dmesh = p_dmesh;
}


void MeshDecimater::run()
{
    decimate();

    emit hasChangedMesh();
}


/**
  * Decimate a mesh with maximum error threashold.
  * @param f_maxError the maximum error threashold
  */
void MeshDecimater::decimate()
{
    unsigned i_nbVertices = p_dmesh->n_vertices();
    unsigned i_LOD = 0;

    while (i_nbVertices > 100)
    {
        p_dmesh->performedOperations.push_back(PerformedOperationMap());

        // Compute the cost of each halfedge collapse.
        computeCollapseCosts();

        std::cout << "Generate level of details n°" << i_LOD << ".\n";

        bool b_noOperationPerformed = true;
        while (1)
        {
            // Find the halfedge collapse operation with the minimal error.
            CollapseCandidate cc;
            bool b_collapseCandidateFound = false;
            while (!collapseCandidates.empty())
            {
                cc = collapseCandidates.top();
                collapseCandidates.pop();

                if (!p_dmesh->status(p_dmesh->edge_handle(cc.heh)).deleted()
                        && p_dmesh->data(cc.heh).b_collapseOk)
                {
                    assert(!p_dmesh->status(cc.v2).deleted());
                    b_collapseCandidateFound = true;
                    break;
                }
            }

            if (!b_collapseCandidateFound)
                break;

            performCollapse(cc, i_LOD);
            i_nbVertices--;
            b_noOperationPerformed = false;
        }

        i_LOD++;
        if (b_noOperationPerformed)
            break;

        // Update face normals.
        for (DeciMesh::FaceIter  f_it = p_dmesh->faces_begin();
             f_it != p_dmesh->faces_end(); ++f_it)
            if (!p_dmesh->status(f_it).deleted())
                p_dmesh->update_normal(f_it);
    }

    p_dmesh->i_nbVerticesBaseMesh = i_nbVertices;

    cout << "Nb LOD: " << i_LOD << endl;
}


/**
  * Perform an halfedge collapse.
  * @param heh the halfedge handle to collapse.
  */
void MeshDecimater::performCollapse(const CollapseCandidate &cc, unsigned i_LOD)
{
    const DeciMesh::HalfedgeHandle heh = cc.heh;
    const DeciMesh::HalfedgeHandle hehOpp = p_dmesh->opposite_halfedge_handle(heh);
    const DeciMesh::VertexHandle v2 = cc.v2;
    const DeciMesh::VertexHandle vh_to = p_dmesh->to_vertex_handle(heh);
    const DeciMesh::VertexHandle vh_from = p_dmesh->from_vertex_handle(heh);


    // Find which of the remaining edge will be the best predictor.
    PerformedOperation op;

    assert(!p_dmesh->status(v2).deleted());

    list<VertexHandle> vrNeighborsBefore;
    for (DeciMesh::ConstVertexVertexIter vv_it = p_dmesh->cvv_iter(vh_from);
         vv_it; ++vv_it)
        vrNeighborsBefore.push_back(vv_it);

    op.vhPivotL = p_dmesh->to_vertex_handle(p_dmesh->next_halfedge_handle(heh));
    op.vhPivotR = p_dmesh->to_vertex_handle(p_dmesh->next_halfedge_handle(hehOpp));

    op.v1 = vh_to;
    op.v2 = v2;
    op.vr = vh_from;

    p_dmesh->performedOperations[i_LOD].insert(PerformedOperationPair(op.v1, op));

    // Collapse the halfedge.
    p_dmesh->collapse(heh);

    assert(!p_dmesh->status(vh_to).deleted());

    for (list<VertexHandle>::iterator it = vrNeighborsBefore.begin();
         it != vrNeighborsBefore.end(); ++it)
        for (DeciMesh::ConstVertexOHalfedgeIter voh_it = p_dmesh->cvoh_iter(*it);
             voh_it; ++voh_it)
            p_dmesh->data(voh_it).b_collapseOk = false;

    for (list<VertexHandle>::iterator it = vrNeighborsBefore.begin();
         it != vrNeighborsBefore.end(); ++it)
        for (DeciMesh::ConstVertexIHalfedgeIter vih_it = p_dmesh->cvih_iter(*it);
             vih_it; ++vih_it)
            if (p_dmesh->data(vih_it).b_collapseOk)
                p_dmesh->data(vih_it).b_collapseOk = p_dmesh->is_collapse_ok(vih_it);
}

