/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "meshDecimaterTraits.hpp"

#include <queue>


/**
  * Compute the surface of a triangular face.
  * @param fh the face handle.
  * @return the face surface.
  */
float DeciMesh::calc_face_surface(FaceHandle fh) const
{
    ConstFaceVertexIter fv_it = cfv_iter(fh);
    DeciMesh::VertexHandle p[] = {fv_it, ++fv_it, ++fv_it};

    return calc_face_surface(p);
}


/**
  * Compute the surface of a triangular face.
  * @param polygonVertices the face vertex handle.
  * @return the face surface.
  */
float DeciMesh::calc_face_surface(VertexHandle polygonVertices[]) const
{
    const DeciMesh::Point p[] = {point(polygonVertices[0]),
                                 point(polygonVertices[1]),
                                 point(polygonVertices[2])};

    float a = (p[0] - p[1]).norm();
    float b = (p[1] - p[2]).norm();
    float c = (p[2] - p[0]).norm();
    float s = (a + b + c) / 2;
    float f_sqSurface = s * (s - a) * (s - b) * (s - c);
    return f_sqSurface <= 0 ? 0 : sqrt(f_sqSurface);
}


/**
  * Compute the mesh bounding box.
  */
void DeciMesh::updateBoundingBox()
{
    ConstVertexIter vIt(vertices_begin());
    ConstVertexIter vEnd(vertices_end());

    bbMin = bbMax = point(vIt);

    for (size_t count = 0; vIt != vEnd; ++vIt, ++count)
    {
        bbMin.minimize(point(vIt));
        bbMax.maximize(point(vIt));
    }

    float f_maxRange = 0;
    for (unsigned i = 0; i < 3; ++i)
    {
        float range = bbMax[i] - bbMin[i];
        f_maxRange = max(range, f_maxRange);
    }
    f_quantStep = f_maxRange / (1 << i_nbQuantBits);
    cout << "Quantization step: " << f_quantStep << "\n";
}


/**
  * Convert an float position into a quantized integer position.
  * @param p the float position.
  * @return the integer quantized position.
  */
Vec3i DeciMesh::floatPosToInt(Point p) const
{
    return OpenMesh::Vec3i((p[0] - bbMin[0]) / f_quantStep,
                           (p[1] - bbMin[1]) / f_quantStep,
                           (p[2] - bbMin[2]) / f_quantStep);
}


/**
  * Convert an integer quantized position into a float position.
  * @param p the integer quantized position.
  * @return the float position.
  */
DeciMesh::Point DeciMesh::intPosToFloat(Vec3i p) const
{
    return Point(bbMin[0] + (p[0] + 0.5) * f_quantStep,
                 bbMin[1] + (p[1] + 0.5) * f_quantStep,
                 bbMin[2] + (p[2] + 0.5) * f_quantStep);
}


/**
  * Quantize the positions of all the vertices of a mesh.
  */
void DeciMesh::quantizeVertexPositions()
{
    int i_maxCoord = 1 << i_nbQuantBits;

    for (VertexIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it)
    {
        const VertexHandle vh = v_it.handle();
        const Point p = point(vh);

        OpenMesh::Vec3i p_quant = floatPosToInt(p);

        /* The max value is the unique that have to to be reassigned
           because else it would get out the range. */
        p_quant = Vec3i(p_quant[0] == i_maxCoord ? i_maxCoord - 1 : p_quant[0],
                        p_quant[1] == i_maxCoord ? i_maxCoord - 1 : p_quant[1],
                        p_quant[2] == i_maxCoord ? i_maxCoord - 1 : p_quant[2]);

        Point new_p = intPosToFloat(p_quant);

        set_point(vh, new_p);
    }
}


/**
  * Get the maximum length of the given vertex adjacent edges.
  * @param vh the vertex handle.
  * @return the maximum length.
  */
float DeciMesh::maxNeighborEdgesLength(const VertexHandle vh)
{
    float f_maxLength = 0;
    for (ConstVertexEdgeIter ve_it = cve_iter(vh); ve_it; ++ve_it)
        f_maxLength = max(f_maxLength, calc_edge_length(ve_it));
    return f_maxLength;
}


/**
  * Get the quantized position of a given vertex.
  * @param vh the vertex handle.
  * @return the quantized position.
  */
Vec3i DeciMesh::getQuantPos(const VertexHandle vh) const
{
    return floatPosToInt(point(vh));
}


/**
  * Assign a number to each cluster of the mesh
  * in a deterministic manner.
  * Save also the seed halfedge handles.
  */
void DeciMesh::numberClusters()
{
    for (ConstVertexIter v_it = vertices_begin();
         v_it != vertices_end(); ++v_it)
        data(v_it).b_conquered = false;

    queue<DeciMesh::HalfedgeHandle> hehQueue;
    hehQueue.push(clusterSeedHeh[0]);

    unsigned i_clusterId = 1;
    while (!hehQueue.empty())
    {
        const DeciMesh::HalfedgeHandle hehEntry = hehQueue.front();
        hehQueue.pop();

        const DeciMesh::VertexHandle vhTo = to_vertex_handle(hehEntry);

        if (data(vhTo).b_conquered)
            continue;

        data(vhTo).i_clusterId = i_clusterId++;
        clusterSeedHeh.push_back(hehEntry);

        // Mark it as conquered.
        data(vhTo).b_conquered = true;

        // Add neighboring halfedges to que queue.
        const DeciMesh::HalfedgeHandle hehEntryOpp = opposite_halfedge_handle(hehEntry);
        HalfedgeHandle hehIt = hehEntryOpp;
        do
        {
            hehIt = prev_halfedge_handle(hehIt);
            hehIt = opposite_halfedge_handle(hehIt);
            hehQueue.push(hehIt);
        }
        while (hehIt != hehEntryOpp);
    }

    i_nbClusters = i_clusterId;
}


/**
  * Mark the halfedges to not count during encoding and decoding
  * of the vertex splits.
  * @param i_clusterId the current cluster Id,
  * @param op the previous performed operation.
  */
void DeciMesh::markEdgesToNotCount(unsigned i_clusterId, const PerformedOperation &op)
{
    // Mark the halfedges that now do not need to be counted because they
    // can't be split.
    HalfedgeHandle hehIt = find_halfedge(op.v1, op.vhPivotL);
    const HalfedgeHandle hehEnd = find_halfedge(op.v1, op.vhPivotR);
    while (hehIt != hehEnd)
    {
        markEdgeHalfedgesToNotCount(i_clusterId, hehIt);
        hehIt = next_halfedge_handle(hehIt);
        markEdgeHalfedgesToNotCount(i_clusterId, hehIt);
        hehIt = next_halfedge_handle(hehIt);
        hehIt = opposite_halfedge_handle(hehIt);
    }
    markEdgeHalfedgesToNotCount(i_clusterId, hehIt);
}


/**
  * Mark the edge halfedges to not count.
  * @param i_clusterId the current cluster Id,
  * @param heh one edge halfedge.
  */
void DeciMesh::markEdgeHalfedgesToNotCount(unsigned i_clusterId, HalfedgeHandle heh)
{
    if (data(to_vertex_handle(heh)).i_clusterId == i_clusterId)
        data(heh).b_dontCount = true;

    const HalfedgeHandle hehOpp = opposite_halfedge_handle(heh);
    if (data(to_vertex_handle(hehOpp)).i_clusterId == i_clusterId)
        data(hehOpp).b_dontCount = true;
}


/**
  * Test if an edge collapse will not violate the manifold property of the mesh.
  * Fastest implementation of the TriConnectivity is_collapse_ok function.
  * We do not handle meshes with boundaries.
  * This function do not write data on the mesh.
  * @param v0v1 the halfedge to collapse.
  */
bool DeciMesh::is_collapse_ok(HalfedgeHandle v0v1) const
{
    const HalfedgeHandle v1v0(opposite_halfedge_handle(v0v1));
    const VertexHandle v0(to_vertex_handle(v1v0));
    const VertexHandle v1(to_vertex_handle(v0v1));
    const VertexHandle vl = to_vertex_handle(next_halfedge_handle(v0v1));
    const VertexHandle vr = to_vertex_handle(next_halfedge_handle(v1v0));

    // if vl and vr are equal or both invalid -> fail
    if (vl == vr)
        return false;

    // test intersection of the one-rings of v0 and v1
    for (ConstVertexVertexIter vv_it = cvv_iter(v0); vv_it; ++vv_it)
    {
        VertexHandle vhIt = vv_it.handle();
        if (vhIt != vl && vhIt != vr && areVerticesConnected(vhIt, v1))
            return false;
    }

    // passed all tests
    return true;
}


/**
  * Collapse a halfedge on a triangular mesh.
  * Do not handle meshes with boundaries.
  * @param h the halfedge to collapse.
  */
void DeciMesh::collapse(HalfedgeHandle h)
{
    HalfedgeHandle  hn = next_halfedge_handle(h);
    HalfedgeHandle  hp = prev_halfedge_handle(h);
    HalfedgeHandle  hpo = opposite_halfedge_handle(hp);

    HalfedgeHandle  o  = opposite_halfedge_handle(h);
    HalfedgeHandle  on = next_halfedge_handle(o);
    HalfedgeHandle  op = prev_halfedge_handle(o);
    HalfedgeHandle  ono = opposite_halfedge_handle(on);

    FaceHandle      fh = face_handle(h);
    FaceHandle      fo = face_handle(o);

    VertexHandle    vh = to_vertex_handle(h);
    VertexHandle    vo = to_vertex_handle(o);

    VertexHandle    vl = to_vertex_handle(hn);
    VertexHandle    vr = to_vertex_handle(on);

    // halfedge -> vertex
    for (ConstVertexIHalfedgeIter vih_it(cvih_iter(vo)); vih_it; ++vih_it)
        set_vertex_handle(vih_it.handle(), vh);

    // vertex -> halfedge
    if (halfedge_handle(vh) == o)
        set_halfedge_handle(vh, hn);

    if (halfedge_handle(vl) == hp)
        set_halfedge_handle(vl, next_halfedge_handle(hpo));

    if (halfedge_handle(vr) == ono)
        set_halfedge_handle(vr, op);

    // halfedge -> next halfedge
    set_next_halfedge_handle(hn, next_halfedge_handle(hpo));
    set_next_halfedge_handle(next_halfedge_handle(next_halfedge_handle(hn)), hn);

    set_next_halfedge_handle(op, next_halfedge_handle(ono));
    set_next_halfedge_handle(next_halfedge_handle(next_halfedge_handle(op)), op);

    // face -> halfedge
    set_halfedge_handle(face_handle(hpo), hn);
    set_halfedge_handle(face_handle(ono), op);

    // halfedge -> face
    set_face_handle(hn, face_handle(hpo));
    set_face_handle(op, face_handle(ono));

    // delete stuff
    status(edge_handle(h)).set_deleted(true);
    status(edge_handle(on)).set_deleted(true);
    status(edge_handle(hp)).set_deleted(true);
    status(vo).set_deleted(true);
    status(fh).set_deleted(true);
    status(fo).set_deleted(true);
}
