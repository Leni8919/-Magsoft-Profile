/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <iostream>

#include <QTimer>

#include "POMARAppli.hpp"

#include "GUI/window.h"


POMARAppli::POMARAppli(int &argc, char **argv)
    : QApplication(argc, argv)
{
    std::cout << "+-------------------------------------------------------------------------+" << std::endl;
    std::cout << "|                                POMAR  codec                             |" << std::endl;
    std::cout << "|             Progressive Oriented Meshes Accessible Randomly             |" << std::endl;
    std::cout << "|                             v0.1 - August 2012                          |" << std::endl;
    std::cout << "|           Adrien Maglo - MAS laboratory, Ecole Centrale Paris           |" << std::endl;
    std::cout << "+-------------------------------------------------------------------------+" << std::endl;

    QStringList args = arguments();

    bool b_randomAccess = true;
    bool b_compression = true;
    bool b_gui = false;
    bool b_help = false;
    unsigned i_nbQuantBits = 12;
    char *psz_filePath = NULL;

    bool b_commandLineError = false;

    // Parse the command line arguments.
    for (int i = 1; i < args.size(); ++i)
    {
        if (args[i] == "-c")
            b_compression = true;
        else if (args[i] == "-d")
        {
            b_compression = false;
            b_gui = true;
        }
        else if (args[i] == "--gui")
            b_gui = true;
        else if (args[i] == "-h")
            b_help = true;
        else if (args[i] == "--disable-random-access")
            b_randomAccess = false;
        else if (args[i] == "-q")
        {
            if (i + 1 < args.size())
            {
                bool b_ok;
                i_nbQuantBits = args[++i].toInt(&b_ok);
                if (!b_ok || i_nbQuantBits > 16 || i_nbQuantBits < 2)
                {
                    cout << "Wrong number of quantization bits." << endl;
                    b_commandLineError = true;
                }
            }
            else
                b_commandLineError = true;
        }
        else
        {
            free(psz_filePath);
            psz_filePath = strdup(args[i].toUtf8().data());
        }
    }

    // Given the command line, perform the actions.
    if (psz_filePath == NULL && !b_help)
    {
        cout << "No file specified." << endl;
        b_commandLineError = true;
    }

    p_handler = new MeshHandler(b_compression, b_gui, b_randomAccess);
    if (!b_commandLineError && !b_help)
    {
        p_handler->loadMesh(psz_filePath, i_nbQuantBits);

        if (b_gui)
        {
            Window *p_window = new Window(p_handler);
            p_window->show();
        }
        else
        {
            assert(b_compression);
            QTimer::singleShot(0, this, SLOT(runCompressionWithoutGUI()));
        }
    }
    else
        QTimer::singleShot(0, this, SLOT(printUsageAndQuit()));

    connect(this, SIGNAL(aboutToQuit()), this, SLOT(cleanBeforeClose()));
    free(psz_filePath);
}


void POMARAppli::runCompressionWithoutGUI()
{
    // Decimate and compress the mesh.
    p_handler->decimate();
    p_handler->compress();
    quit();
}


void POMARAppli::cleanBeforeClose()
{
    delete p_handler;
}


void POMARAppli::printUsageAndQuit()
{
    cout << "Usage: " << endl
         << "./POMAR [mode] [options] filePath" << endl
         << "Mode:" << endl
         << "   -c : compression (default mode if none is specified)." << endl
         << "   -d : decompression" << endl
         << endl
         << "Options:" << endl
         << "   --gui : display the GUI. The GUI is always started for the decompression." << endl
         << "   -h : display this help message and quit." << endl
         << "   -q <quantization> : set the number of quantization bits. The default value is 12." << endl
         << "   --disable-random-access : Disable the random access, set the encoder in the progressive mode." << endl;
    quit();
}
