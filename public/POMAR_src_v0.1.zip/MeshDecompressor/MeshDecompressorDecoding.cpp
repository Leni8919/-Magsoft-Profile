/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "MeshDecompressor.hpp"
#include "FrenetRotation/frenetRotation.h"


/**
  * Decode a vertex split.
  * @param heh the halfedge to split.
  * @param i_clusterId the cluster id.
  * @param i_splitId the split id.
  */
PerformedOperation MeshDecompressor::decodeVertexSplit(DeciMesh::HalfedgeHandle heh,
                                                       unsigned i_clusterId,
                                                       unsigned i_splitId)
{
    PerformedOperation op;
    op.v1 = p_dmesh->to_vertex_handle(heh);
    op.v2 = p_dmesh->from_vertex_handle(heh);

    list<DeciMesh::VertexHandle> vrNeighborsBefore;
    vrNeighborsBefore.push_back(op.v2);
    vrNeighborsBefore.push_back(op.v1);

    DeciMesh::HalfedgeHandle hehIt = heh;
    for (unsigned i = 0; i < vertexSplitSymbols[i_clusterId][2 * i_splitId] + 1; ++i)
    {
        hehIt = p_dmesh->next_halfedge_handle(hehIt);
        hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
        vrNeighborsBefore.push_back(p_dmesh->from_vertex_handle(hehIt));
    }
    op.vhPivotL = p_dmesh->from_vertex_handle(hehIt);

    hehIt = p_dmesh->opposite_halfedge_handle(heh);
    for (unsigned i = 0; i < vertexSplitSymbols[i_clusterId][2 * i_splitId + 1] + 1; ++i)
    {
        hehIt = p_dmesh->prev_halfedge_handle(hehIt);
        hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
        vrNeighborsBefore.push_back(p_dmesh->to_vertex_handle(hehIt));
    }
    op.vhPivotR = p_dmesh->to_vertex_handle(hehIt);

    // Compute the barycenter.
    Vec3f barycenter(0,0,0);
    for (list<VertexHandle>::iterator it = vrNeighborsBefore.begin();
         it != vrNeighborsBefore.end(); ++it)
        barycenter = barycenter + p_dmesh->point(*it);
    barycenter = barycenter / vrNeighborsBefore.size();

    // Compute the normal.
    const Vec3f normal = (p_dmesh->calc_face_normal(p_dmesh->face_handle(heh))
                          + p_dmesh->calc_face_normal(p_dmesh->face_handle(p_dmesh->opposite_halfedge_handle(heh)))).normalize_cond();

    // Add the vertex with the decoded coordinates.
    Vec3f t1, t2;
    determineFrenetFrame(p_dmesh->point(op.v1), p_dmesh->point(op.v2), normal, t1, t2);
    Vec3i decodedFresnet(geometrySymbols[i_clusterId][2 * i_splitId],
                         geometrySymbols[i_clusterId][2 * i_splitId + 1],
                         geometryNormalSymbols[i_clusterId][i_splitId]);

    Vec3i residual = invFrenetRotation(decodedFresnet, t1, t2, normal);
    Vec3i predPos = p_dmesh->floatPosToInt(barycenter);
    Vec3i vrPos = predPos + residual;

    op.vr = p_dmesh->add_vertex(p_dmesh->intPosToFloat(vrPos));

    p_dmesh->markEdgesToNotCount(i_clusterId, op);

    return op;
}
