/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <time.h>

#include <OpenMesh/Core/IO/MeshIO.hh>

#include "MeshDecompressor.hpp"


/**
  * Run the mesh decompression.
  */
void MeshDecompressor::run()
{
    clock_t begin = clock();

    // Set the data offset at the begining of the cluster data.
    *p_dataOffset = dataOffsetClusters;

    // Set the LOD to decompress for each cluster.
    unsigned p_requiredNbLOD[p_dmesh->i_nbClusters];
    for (unsigned i = 0; i < p_dmesh->i_nbClusters; ++i)
        p_requiredNbLOD[i] = 0;

    for (set<DeciMesh::VertexHandle>::iterator vh_it = selectedVertices.begin();
         vh_it != selectedVertices.end(); ++vh_it)
        setRequiredNbLOD(*vh_it, p_requiredNbLOD);

    // Write the requiered LOD mesh.
    //writeRequiredLODMesh(p_requiredNbLOD);

    // Decompress the data.
    for (unsigned i_clusterId = 1; i_clusterId < p_dmesh->i_nbClusters; ++i_clusterId)
    {
        size_t offsetStart = *p_dataOffset;
        if (p_requiredNbLOD[i_clusterId] > 0)
            decompressCluster(i_clusterId, p_requiredNbLOD[i_clusterId]);

        symbolIds.push_back(0);
        splitIds.push_back(0);
        *p_dataOffset = offsetStart + p_dmesh->clusterSizes[i_clusterId];
    }

    // Rebuild the LODs.
    for (unsigned i_LOD = 0; i_LOD < p_dmesh->i_nbClusteredLOD; ++i_LOD)
    {
        for (DeciMesh::ConstVertexIter v_it = p_dmesh->vertices_begin();
             v_it != p_dmesh->vertices_end(); ++v_it)
            p_dmesh->data(v_it).b_conquered = false;

        for (DeciMesh::ConstHalfedgeIter h_it = p_dmesh->halfedges_begin();
             h_it != p_dmesh->halfedges_end(); ++h_it)
            p_dmesh->data(h_it).b_dontCount = false;

        std::queue<PerformedOperation> opToPerform;
        for (unsigned i_clusterId = 1; i_clusterId < p_dmesh->i_nbClusters; ++i_clusterId)
            if ((int)i_LOD < p_requiredNbLOD[i_clusterId])
                refineCluster(i_clusterId, opToPerform);

        performOperations(opToPerform);

        //writeMeshLOD(i_LOD);
    }

    //IO::write_mesh(*p_dmesh, "decompressedMesh.off");

    clock_t end = clock();
    unsigned long l_diff = (end - begin) * 1000 / CLOCKS_PER_SEC;
    unsigned i_timeRate = l_diff * 1000 / p_dmesh->n_vertices();
    cout << "The decompression lasted " << l_diff << "ms (" << i_timeRate << "µs/v)." << endl;

    emit hasChangedMesh();
}


/**
  * Decompress the global LOD, the ones that are not clustered.
  */
void MeshDecompressor::decompressGlobalLOD()
{
    clock_t begin = clock();

    // Read the base mesh.
    readCompressedFile();
    readHeaderAndBaseMesh();

    // Compute the face normals.
    p_dmesh->request_face_normals();
    p_dmesh->request_vertex_normals();
    p_dmesh->update_normals();

    nbSkipsHehSymbols.resize(1);
    vertexSplitSymbols.resize(1);
    geometrySymbols.resize(1);
    geometryNormalSymbols.resize(1);
    nbSplitSymbols.resize(1);

    cout << "Offset: " << *p_dataOffset << endl;

    initRangeCoder();
    decompressCluster(0, p_dmesh->i_nbGlobalLOD);

    symbolIds.push_back(0);
    splitIds.push_back(0);

    for (unsigned i_LOD = 0; i_LOD < p_dmesh->i_nbGlobalLOD; ++i_LOD)
    {
        for (DeciMesh::ConstVertexIter v_it = p_dmesh->vertices_begin();
             v_it != p_dmesh->vertices_end(); ++v_it)
            p_dmesh->data(v_it).b_conquered = false;

        for (DeciMesh::ConstHalfedgeIter h_it = p_dmesh->halfedges_begin();
             h_it != p_dmesh->halfedges_end(); ++h_it)
            p_dmesh->data(h_it).b_dontCount = false;

        std::queue<PerformedOperation> opToPerform;
        refineCluster(0, opToPerform);
        performOperations(opToPerform);

        //writeMeshLOD(i_LOD);
    }

    if (p_dmesh->i_nbClusteredLOD > 0)
    {
        // If the random access mode was enabled during the compression.
        // Assign the ids and the seed halfedges for each cluster.
        p_dmesh->numberClusters();

        nbSkipsHehSymbols.resize(p_dmesh->i_nbClusters);
        vertexSplitSymbols.resize(p_dmesh->i_nbClusters);
        geometrySymbols.resize(p_dmesh->i_nbClusters);
        geometryNormalSymbols.resize(p_dmesh->i_nbClusters);
        nbSplitSymbols.resize(p_dmesh->i_nbClusters);

        p_dmesh->clusterSizes.resize(p_dmesh->i_nbClusters);

        // Read the cluster sizes.
        readClusterSizes();

        dataOffsetClusters = *p_dataOffset;
    }

    clock_t end = clock();
    unsigned long l_diff = (end - begin) * 1000 / CLOCKS_PER_SEC;
    unsigned i_timeRate = l_diff * 1000 / p_dmesh->n_vertices();
    cout << "The global levels of detail decompression lasted " << l_diff << "ms (" << i_timeRate << "µs/v)." << endl;
}


/**
  * Refine a cluster. Decompress one level on detail for one cluster.
  * @param i_clusterId the id of the cluster.
  * @param opToPerform countains the decompressed operations to perform.
  */
void MeshDecompressor::refineCluster(unsigned i_clusterId,
                                     std::queue<PerformedOperation> &opToPerform)
{
    queue<DeciMesh::HalfedgeHandle> hehQueue;

    hehQueue.push(p_dmesh->clusterSeedHeh[i_clusterId]);

    while (!hehQueue.empty())
    {
        const DeciMesh::HalfedgeHandle hehEntry = hehQueue.front();
        hehQueue.pop();

        const DeciMesh::VertexHandle vhTo = p_dmesh->to_vertex_handle(hehEntry);

        if (p_dmesh->data(vhTo).i_clusterId != i_clusterId
            || p_dmesh->data(vhTo).b_conquered)
            continue;

        DeciMesh::HalfedgeHandle hehIt = hehEntry;

        // Test if there is some splits for this vertex.
        unsigned &i_symbolId = symbolIds[i_clusterId];
        unsigned i_nbSplits = nbSplitSymbols[i_clusterId][i_symbolId];
        if (i_nbSplits > 0)
        {
            // Rank the candidate halfedges.
            priority_queue<RankedHalfedge> rankedHeh;

            do
            {
                hehIt = p_dmesh->next_halfedge_handle(hehIt);
                hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
                rankedHeh.push(RankedHalfedge(p_dmesh, hehIt));
            }
            while (hehIt != hehEntry);

            for (unsigned i_split = 0; i_split < i_nbSplits; ++i_split)
            {
                unsigned &i_splitId = splitIds[i_clusterId];
                unsigned i_nbSkipsHehSymbol = nbSkipsHehSymbols[i_clusterId][i_splitId];

                unsigned i_skip = 0;
                while (i_skip < i_nbSkipsHehSymbol)
                {
                    if (!p_dmesh->data(rankedHeh.top().heh).b_dontCount)
                        i_skip++;
                    rankedHeh.pop();
                }

                while (p_dmesh->data(rankedHeh.top().heh).b_dontCount)
                    rankedHeh.pop();

                assert(!rankedHeh.empty());
                PerformedOperation op = decodeVertexSplit(rankedHeh.top().heh, i_clusterId, i_splitId);
                rankedHeh.pop();
                opToPerform.push(op);
                i_splitId++;
            }
        }

        // Mark it as conquered.
        p_dmesh->data(vhTo).b_conquered = true;

        // Add neighboring halfedges to que queue.
        const DeciMesh::HalfedgeHandle hehEntryOpp = p_dmesh->opposite_halfedge_handle(hehEntry);
        hehIt = hehEntryOpp;
        do
        {
            hehIt = p_dmesh->prev_halfedge_handle(hehIt);
            hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
            hehQueue.push(hehIt);
        }
        while (hehIt != hehEntryOpp);

        i_symbolId++;
    }
}


/**
  * Perform the given vertex splits operations.
  * @param opToPerform the operations to perform.
  */
void MeshDecompressor::performOperations(std::queue<PerformedOperation> &opToPerform)
{
    unsigned i_nbOpPerformed = 0;
    while (!opToPerform.empty())
    {
        PerformedOperation op = opToPerform.front();
        opToPerform.pop();
        vertexSplit(op);
        i_nbOpPerformed++;
    }
}


/**
  * Split a vertex.
  * @param op the vertex split operation to perform.
  */
void MeshDecompressor::vertexSplit(PerformedOperation &op)
{
    p_dmesh->vertex_split(op.vr, op.v1, op.vhPivotL, op.vhPivotR);
    if (p_dmesh->data(op.v1).b_marked)
        p_dmesh->data(op.vr).b_marked = true;

    p_dmesh->data(op.vr).i_clusterId = p_dmesh->data(op.v1).i_clusterId;

    for (DeciMesh::ConstVertexFaceIter cvf_it = p_dmesh->cvf_iter(op.vr);
         cvf_it; ++cvf_it)
        p_dmesh->update_normal(cvf_it);
}


/**
  * Set the required LOD to the neighbor cluster of one cluster we want to fully
  * decompress.
  * @param vhInit the vertex of the cluster we want to decompress entirely.
  * @param p_requiredNbLOD the required LOD of the neighbor vertex clusters.
  */
void MeshDecompressor::setRequiredNbLOD(const DeciMesh::VertexHandle vhInit,
                                        unsigned p_requiredNbLOD[])
{
    queue<DeciMesh::VertexHandle> vhQueue;
    queue<int> requieredLODQueue;

    vhQueue.push(vhInit);
    requieredLODQueue.push(p_dmesh->i_nbClusteredLOD);

    while (!vhQueue.empty())
    {
        const DeciMesh::VertexHandle vh = vhQueue.front();
        unsigned requieredLOD = requieredLODQueue.front();

        vhQueue.pop();
        requieredLODQueue.pop();

        unsigned i_clusterId = p_dmesh->data(vh).i_clusterId;

        if (p_requiredNbLOD[i_clusterId] < requieredLOD)
        {
            p_requiredNbLOD[i_clusterId] = requieredLOD;
            unsigned nextRequiredLOD = requieredLOD > 0 ? requieredLOD - 1 : 0;
            for (DeciMesh::ConstVertexVertexIter vv_it = p_dmesh->cvv_iter(vh);
                 vv_it; ++vv_it)
            {
                vhQueue.push(vv_it);
                requieredLODQueue.push(nextRequiredLOD);
            }
        }
    }
}


/**
  * Write a file countaining the base clustered mesh where each vertex
  * has a color indicating the level of details its cluster must be decompressed.
  * @param p_requiredNbLOD the required LOD of the clusters.
  */
void MeshDecompressor::writeRequiredLODMesh(unsigned p_requiredNbLOD[])
{
    p_dmesh->request_vertex_colors();

    unsigned i_nbClusteredLOD = p_dmesh->i_nbClusteredLOD;

    Vec3f c1(115, 199, 255);
    Vec3f c2(255, 0, 0);

    Vec3f slope = c2 - c1;

    for (DeciMesh::ConstVertexIter v_it = p_dmesh->vertices_begin();
         v_it != p_dmesh->vertices_end(); ++v_it)
    {
        DeciMesh::Color c;
        float x = (float)p_requiredNbLOD[p_dmesh->data(v_it).i_clusterId] / i_nbClusteredLOD;
        for (unsigned i = 0; i < 3; ++i)
            c[i] = x * slope[i] + c1[i];
        p_dmesh->set_color(v_it, (Vec3uc)c);
    }

    IO::Options writeOption;
    writeOption += IO::Options::VertexColor;

    IO::write_mesh(*p_dmesh, "requiredLODMesh.off", writeOption);

    p_dmesh->release_vertex_colors();
}


/**
  * Write the mesh at the current decompressed LOD.
  * @param i_LOD the current mesh LOD.
  */
void MeshDecompressor::writeMeshLOD(unsigned i_LOD)
{
    std::ostringstream fileName;
    fileName << "decompressedMesh_" << i_LOD << ".off";
    IO::write_mesh(*p_dmesh, fileName.str().c_str());
}
