/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "MeshDecompressor.hpp"


/**
  * Init the structure of the range coder for the decompression.
  */
void MeshDecompressor::initRangeCoder()
{
    rangeCoder.p_data = p_data;
    rangeCoder.p_dataOffset = p_dataOffset;
}


/**
  * Get an unsigned integer in the compressed data.
  * @param rc a pointer to the range coder.
  * @param i_nbBits the bit length of the unsigned integer.
  */
unsigned MeshDecompressor::decodeNbBits(rangecoder *rc, unsigned i_nbBits)
{
    unsigned tmp = decode_culshift(rc, i_nbBits);
    decode_update(rc, 1, tmp, (freq)1 << i_nbBits);
    return tmp;
}


/**
  * Decode the range coder model values and init the models for the decompression.
  * @param i_clusterId
  */
void MeshDecompressor::decodeAndInitModels(unsigned i_clusterId)
{
    unsigned i_nbBits;

    i_nbBits = i_clusterId > 0 ? i_nbBitsNbSplits : 3;
    i_maxNbSplits = decodeNbBits(&rangeCoder, i_nbBits);
    //cout << "Max nb splits: " << i_maxNbSplits << endl;
    initqsmodel(&nbSplitSymbolsModel, i_maxNbSplits + 1, 10, 1 << 9, NULL, 0);

    i_maxNbSkipsHehSymbol = 0;
    i_maxVertexSplits = 0;
    i_minResidual = 0;
    i_maxResidual = 0;
    i_minResidualNormal = 0;
    i_maxResidualNormal = 0;

    if (i_maxNbSplits > 0)
    {
        i_nbBits = i_clusterId > 0 ? i_nbBitsNbSkips : 4;
        i_maxNbSkipsHehSymbol = decodeNbBits(&rangeCoder, i_nbBits);
        //cout << "Max Heh Symbol: " << i_maxNbSkipsHehSymbol << endl;
        initqsmodel(&nbSkipsHehSymbolsModel, i_maxNbSkipsHehSymbol + 1, 10, 1 << 9, NULL, 0);

        i_nbBits = i_clusterId > 0 ? i_nbBitsVertexSplits : 5;
        i_maxVertexSplits = decodeNbBits(&rangeCoder, i_nbBits);
        //cout << "Max vertex split symbol: " << i_maxVertexSplits << endl;
        initqsmodel(&vertexSplitSymbolsModel, i_maxVertexSplits + 1, 10, 1 << 9, NULL, 0);

        if (i_clusterId > 0)
        {
            i_minResidual = decodeNbBits(&rangeCoder, i_nbBitsMinResidual) + i_minMinResidual;
            i_maxResidual = decodeNbBits(&rangeCoder, i_nbBitsResidualRange) + i_minResidual;
        }
        else
        {
            uint16_t i16_min;
            i16_min = decode_short(&rangeCoder);
            i_minResidual = *(int16_t *)&i16_min;
            i_maxResidual = i_minResidual + decode_short(&rangeCoder);
        }
        //cout << "Tangential components min: " << i_minResidual << " range: " << i_maxResidual - i_minResidual << endl;
        initqsmodel(&geometrySymbolsModel, i_maxResidual - i_minResidual, 18, 1 << 17, NULL, 0);

        if (i_clusterId > 0)
        {
            i_minResidualNormal = decodeNbBits(&rangeCoder, i_nbBitsMinResidualNormal) + i_minMinResidualNormal;
            i_maxResidualNormal = decodeNbBits(&rangeCoder, i_nbBitsResidualNormalRange) + i_minResidualNormal;
        }
        else
        {
            uint16_t i16_min = decode_short(&rangeCoder);
            i_minResidualNormal = *(int16_t *)&i16_min;
            i_maxResidualNormal = i_minResidualNormal + decode_short(&rangeCoder);
        }
        //cout << "Normal component min: " << i_minResidualNormal << " range: " << i_maxResidualNormal - i_minResidualNormal << endl;
        initqsmodel(&geometryNormalSymbolsModel, i_maxResidualNormal - i_minResidualNormal, 18, 1 << 17, NULL, 0);
    }
}


/**
  * Decompress the symbols of cluster for a given number of LOD.
  * @param i_clusterId the cluster id.
  * @param i_maxLOD the last LOD that must be decompressed.
  */
void MeshDecompressor::decompressCluster(unsigned i_clusterId, unsigned i_maxLOD)
{
    cout << "Decompressing cluster " << i_clusterId << endl;

    start_decoding(&rangeCoder);
    decodeAndInitModels(i_clusterId);

    unsigned i_nbVertices = i_clusterId == 0 ? p_dmesh->n_vertices() : 1;

    for (unsigned i_LOD = 0; i_LOD < i_maxLOD; ++i_LOD)
    {
        unsigned i_nbAddedVertices = 0;

        for (unsigned i_vertex = 0; i_vertex < i_nbVertices; ++i_vertex)
        {
            // Decode the number of splits for the current vertex.
            int syfreq, ltfreq;
            ltfreq = decode_culshift(&rangeCoder, 10);
            unsigned i_nbSplits = qsgetsym(&nbSplitSymbolsModel, ltfreq);
            qsgetfreq(&nbSplitSymbolsModel, i_nbSplits, &syfreq, &ltfreq);
            decode_update(&rangeCoder, syfreq, ltfreq, 1 << 10);
            qsupdate(&nbSplitSymbolsModel, i_nbSplits);

            nbSplitSymbols[i_clusterId].push_back(i_nbSplits);

            for (unsigned i_split = 0; i_split < i_nbSplits; ++i_split)
            {
                // Decode the number of halfedge skips.

                ltfreq = decode_culshift(&rangeCoder, 10);
                unsigned i_nbSkipsHehSymbol = qsgetsym(&nbSkipsHehSymbolsModel, ltfreq);
                qsgetfreq(&nbSkipsHehSymbolsModel, i_nbSkipsHehSymbol, &syfreq, &ltfreq);
                decode_update(&rangeCoder, syfreq, ltfreq, 1 << 10);
                qsupdate(&nbSkipsHehSymbolsModel, i_nbSkipsHehSymbol);
                nbSkipsHehSymbols[i_clusterId].push_back(i_nbSkipsHehSymbol);

                // Decode the vertex splits symbols.

                ltfreq = decode_culshift(&rangeCoder, 10);
                unsigned i_vertexSplitSymbol = qsgetsym(&vertexSplitSymbolsModel, ltfreq);
                qsgetfreq(&vertexSplitSymbolsModel, i_vertexSplitSymbol, &syfreq, &ltfreq);
                decode_update(&rangeCoder, syfreq, ltfreq, 1 << 10);
                qsupdate(&vertexSplitSymbolsModel, i_vertexSplitSymbol);
                vertexSplitSymbols[i_clusterId].push_back(i_vertexSplitSymbol);

                ltfreq = decode_culshift(&rangeCoder, 10);
                i_vertexSplitSymbol = qsgetsym(&vertexSplitSymbolsModel, ltfreq);
                qsgetfreq(&vertexSplitSymbolsModel, i_vertexSplitSymbol, &syfreq, &ltfreq);
                decode_update(&rangeCoder, syfreq, ltfreq, 1 << 10);
                qsupdate(&vertexSplitSymbolsModel, i_vertexSplitSymbol);
                vertexSplitSymbols[i_clusterId].push_back(i_vertexSplitSymbol);

                // Decode the geometry tangential components.

                ltfreq = decode_culshift(&rangeCoder, 18);
                unsigned i_geomTangentialSymbol = qsgetsym(&geometrySymbolsModel, ltfreq);
                qsgetfreq(&geometrySymbolsModel, i_geomTangentialSymbol, &syfreq, &ltfreq);
                decode_update(&rangeCoder, syfreq, ltfreq, 1 << 18);
                qsupdate(&geometrySymbolsModel, i_geomTangentialSymbol);
                geometrySymbols[i_clusterId].push_back(i_geomTangentialSymbol + i_minResidual);

                ltfreq = decode_culshift(&rangeCoder, 18);
                i_geomTangentialSymbol = qsgetsym(&geometrySymbolsModel, ltfreq);
                qsgetfreq(&geometrySymbolsModel, i_geomTangentialSymbol, &syfreq, &ltfreq);
                decode_update(&rangeCoder, syfreq, ltfreq, 1 << 18);
                qsupdate(&geometrySymbolsModel, i_geomTangentialSymbol);
                geometrySymbols[i_clusterId].push_back(i_geomTangentialSymbol + i_minResidual);

                // Decode the geometry normal component.

                ltfreq = decode_culshift(&rangeCoder, 18);
                unsigned i_geomNormalSymbol = qsgetsym(&geometryNormalSymbolsModel, ltfreq);
                qsgetfreq(&geometryNormalSymbolsModel, i_geomNormalSymbol, &syfreq, &ltfreq);
                decode_update(&rangeCoder, syfreq, ltfreq, 1 << 18);
                qsupdate(&geometryNormalSymbolsModel, i_geomNormalSymbol);
                geometryNormalSymbols[i_clusterId].push_back(i_geomNormalSymbol + i_minResidualNormal);
            }

            i_nbAddedVertices += i_nbSplits;
        }

        i_nbVertices += i_nbAddedVertices;

        //cout << *p_dataOffset * 8 << endl;
    }

    done_decoding(&rangeCoder);
    deleteModels();
}


/**
  * Delete the range coder models.
  */
void MeshDecompressor::deleteModels()
{
    deleteqsmodel(&nbSplitSymbolsModel);
    if (i_maxNbSplits > 0)
    {
        deleteqsmodel(&nbSkipsHehSymbolsModel);
        deleteqsmodel(&vertexSplitSymbolsModel);
        deleteqsmodel(&geometrySymbolsModel);
        deleteqsmodel(&geometryNormalSymbolsModel);
    }
}
