/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef MESHDECOMPRESSOR_HPP
#define MESHDECOMPRESSOR_HPP

#include <stdint.h>
#include <queue>

#include "Mesh/MeshWorker.h"
#include "MeshDecimater/meshDecimaterTraits.hpp"

#include "RangeCoder/rangecod.h"
#include "RangeCoder/qsmodel.h"

#include "Mesh/RankedHalfedge.hpp"


class MeshDecompressor : public MeshWorker
{
public:
    MeshDecompressor(QWaitCondition *p_waitToContinue)
        : MeshWorker(p_waitToContinue) { }

    void setData(DeciMesh *p_dmesh, QString filePathInput)
    {
        this->p_dmesh = p_dmesh;
        this->filePathInput = filePathInput;
    }

    void decompressGlobalLOD();
    void setData(set<DeciMesh::VertexHandle> selectedVertices) {this->selectedVertices = selectedVertices;}
    void run();

private:
    void refineCluster(unsigned i_clusterId,
                       std::queue<PerformedOperation> &opToPerform);
    void performOperations(std::queue<PerformedOperation> &opToPerform);
    void vertexSplit(PerformedOperation &op);
    void setRequiredNbLOD(const DeciMesh::VertexHandle vhInit,
                          unsigned p_requiredLOD[]);
    void writeRequiredLODMesh(unsigned p_requiredNbLOD[]);
    void writeMeshLOD(unsigned i_LOD);

    // Decoding
    PerformedOperation decodeVertexSplit(DeciMesh::HalfedgeHandle heh,
                                         unsigned i_clusterId,
                                         unsigned i_splitId);

    // Decompression
    void initRangeCoder();
    unsigned decodeNbBits(rangecoder *rc, unsigned i_nbBits);
    void decodeAndInitModels(unsigned i_clusterId);
    void decompressCluster(unsigned i_clusterId, unsigned i_maxLOD);
    void deleteModels();

    // Input
    void readHeaderAndBaseMesh();
    int readCompressedFile();
    void readClusterSizes();
    uint32_t readBits(unsigned i_nbBits, char *p_src,
                      unsigned &i_bitOffset, size_t &offset);
    float readFloat();
    uint8_t readUInt8();
    int16_t readInt16();

    DeciMesh *p_dmesh;

    set<DeciMesh::VertexHandle> selectedVertices;

    vector<deque<unsigned> > nbSplitSymbols;
    vector<deque<unsigned> > nbSkipsHehSymbols;
    vector<deque<unsigned> > vertexSplitSymbols;
    vector<deque<int> > geometrySymbols;
    vector<deque<int> > geometryNormalSymbols;

    deque<unsigned> symbolIds;
    deque<unsigned> splitIds;

    unsigned i_nbBitsNbSplits;
    unsigned i_nbBitsNbSkips;
    unsigned i_nbBitsVertexSplits;
    unsigned i_nbBitsMinResidual;
    unsigned i_nbBitsResidualRange;
    unsigned i_nbBitsMinResidualNormal;
    unsigned i_nbBitsResidualNormalRange;

    int i_minMinResidual;
    int i_minMinResidualNormal;

    rangecoder rangeCoder;

    qsmodel nbSkipsHehSymbolsModel, vertexSplitSymbolsModel,
            nbSplitSymbolsModel,
            geometrySymbolsModel, geometryNormalSymbolsModel;

    char *p_data;
    size_t *p_dataOffset;
    size_t dataOffsetClusters;

    unsigned i_maxNbSplits;
    unsigned i_maxNbSkipsHehSymbol;
    unsigned i_maxVertexSplits;
    int i_minResidual;
    int i_maxResidual;
    int i_minResidualNormal;
    int i_maxResidualNormal;

    QString filePathInput;
};

#endif // MESHDECOMPRESSOR_HPP
