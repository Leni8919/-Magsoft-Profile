/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <fstream>

#include "MeshDecompressor.hpp"


/**
  * Read the file header and the base mesh.
  * @return the reference halfedge handle for the global LOD.
  */
void MeshDecompressor::readHeaderAndBaseMesh()
{
    cout << "Read the header and the base mesh." << endl;

    // Read the codec version.
    unsigned i_codecVersion = readUInt8();
    assert(i_codecVersion == 1); // Ensure that the file is from the first version.

    // Read the bounding box min coordinate.
    for (unsigned i = 0; i < 3; ++i)
        p_dmesh->bbMin[i] = readFloat();
    // Read the quantization step.
    p_dmesh->f_quantStep = readFloat();
    cout << p_dmesh->f_quantStep << endl;

    unsigned i_bitOffset = 0;
    (*p_dataOffset)++;

    p_dmesh->i_nbQuantBits = readBits(4, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset) + 1;
    unsigned i_nbVerticesBaseMesh = readBits(16, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    unsigned i_nbFacesBaseMesh = readBits(16, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    unsigned i_nbBitsPerVertex = ceil(log(i_nbVerticesBaseMesh) / log(2));
    cout << "Base mesh: " << i_nbVerticesBaseMesh << " vertices and " << i_nbFacesBaseMesh << " faces." << endl;

    // Read the vertex positions and add them in the mesh.
    for (unsigned i = 0; i < i_nbVerticesBaseMesh; ++i)
    {
        Vec3i p;
        for (unsigned j = 0; j < 3; ++j)
            p[j] = readBits(p_dmesh->i_nbQuantBits, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
        p_dmesh->add_vertex(p_dmesh->intPosToFloat(p));
    }

    // Read the face vertex indices and add the faces to the mesh.
    DeciMesh::VertexHandle vhHehFirst[2];
    for (unsigned i = 0; i < i_nbFacesBaseMesh; ++i)
    {
        DeciMesh::VertexHandle vhs[3];
        for (unsigned j = 0; j < 3; ++j)
            vhs[j] = DeciMesh::VertexHandle(readBits(i_nbBitsPerVertex, p_data + *p_dataOffset - 1,
                                                     i_bitOffset, *p_dataOffset));
        p_dmesh->add_face(vhs, 3);

        if (i == 0)
        {
            vhHehFirst[0] = vhs[0];
            vhHehFirst[1] = vhs[1];
        }
    }

    p_dmesh->i_nbGlobalLOD = readBits(6, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    p_dmesh->i_nbClusteredLOD = readBits(6, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);

    cout << p_dmesh->i_nbGlobalLOD << " global levels of details" << endl;
    cout << p_dmesh->i_nbClusteredLOD << " clustered levels of details" << endl;

    if(i_bitOffset == 0)
        (*p_dataOffset)--;

    // Compute the max coordinate of the bounding box.
    p_dmesh->bbMax = p_dmesh->bbMin;
    for (DeciMesh::ConstVertexIter v_it = p_dmesh->vertices_begin();
         v_it != p_dmesh->vertices_end(); ++v_it)
        p_dmesh->bbMax.maximize(p_dmesh->point(v_it));

    p_dmesh->clusterSeedHeh.push_back(p_dmesh->find_halfedge(vhHehFirst[0], vhHehFirst[1]));
}


/**
  * Read the size in bytes of each cluster and store them.
  */
void MeshDecompressor::readClusterSizes()
{
    unsigned i_bitOffset = 0;
    (*p_dataOffset)++;

    // Read the number of bits needed to write the cluster sizes.
    unsigned i_nbBitsPerClusterSize = readBits(4, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);

    for (unsigned i_clusterId = 1; i_clusterId < p_dmesh->i_nbClusters;
         ++i_clusterId)
        p_dmesh->clusterSizes[i_clusterId] = readBits(i_nbBitsPerClusterSize, p_data + *p_dataOffset - 1,
                                                      i_bitOffset, *p_dataOffset);

    // Read the number of bits used to code the range values for the clusters.

    i_nbBitsNbSplits = readBits(3, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_nbBitsNbSkips = readBits(3, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_nbBitsVertexSplits = readBits(3, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_nbBitsMinResidual = readBits(5, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_nbBitsResidualRange = readBits(5, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_nbBitsMinResidualNormal = readBits(5, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_nbBitsResidualNormalRange = readBits(5, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);

    if(i_bitOffset == 0)
        (*p_dataOffset)--;

    i_minMinResidual = readInt16();
    i_minMinResidualNormal = readInt16();
}


/**
  * Read a given number of bits in a buffer.
  */
uint32_t MeshDecompressor::readBits(unsigned i_nbBits, char *p_src,
                                    unsigned &i_bitOffset, size_t &offset)
{
    assert(i_nbBits <= 25);

    // Build the mask.
    uint32_t mask = 0;
    for (unsigned i = 0; i < 32 - i_bitOffset; ++i)
        mask |= 1 << i;
    // Swap the mask bytes because the x86 architecture is little endian.
    mask = __builtin_bswap32(mask); // Call a GCC builtin function.

    uint32_t data = *(uint32_t *)p_src & mask;

    // Swap the integer bytes because the x86 architecture is little endian.
    data = __builtin_bswap32(data); // Call a GCC builtin function.

    data >>= 32 - i_nbBits - i_bitOffset;

    // Update the size and offset.
    offset += (i_bitOffset + i_nbBits) / 8;
    i_bitOffset = (i_bitOffset + i_nbBits) % 8;

    return data;
}


/**
  * Read a floating point number in the data buffer.
  */
float MeshDecompressor::readFloat()
{
    float f = *(float *)(p_data + *p_dataOffset);
    *p_dataOffset += sizeof(float);
    return f;
}


/**
  * Read a 8 bits unsigned integer in the data buffer.
  */
uint8_t MeshDecompressor::readUInt8()
{
    uint8_t i = *(uint8_t *)(p_data + *p_dataOffset);
    *p_dataOffset += sizeof(uint8_t);
    return i;
}


/**
  * Read a 8 bits signed integer in the data buffer.
  */
int16_t MeshDecompressor::readInt16()
{
    int16_t i = *(int16_t *)(p_data + *p_dataOffset);
    *p_dataOffset += sizeof(int16_t);
    return i;
}


/**
  * Read the compressed data from the file and store them in a buffer.
  */
int MeshDecompressor::readCompressedFile()
{
    int i_ret = 1;

    cout << "Read the compressed file " << filePathInput.toUtf8().data() << endl;

    std::filebuf fb;
    fb.open(filePathInput.toUtf8().data(), std::ios::in);

    if (fb.is_open())
    {
        std::streamsize dataSize = fb.in_avail();
        p_data = new char[dataSize];
        if (fb.sgetn(p_data, dataSize) == (std::streamsize)dataSize)
            i_ret = 0;
        fb.close();

        p_dataOffset = new size_t;
        *p_dataOffset = 0;
    }

    return i_ret;
}
