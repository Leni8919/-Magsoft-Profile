/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef MESHWORKER_H
#define MESHWORKER_H

#include <QThread>
#include <QMutex>
#include <QWaitCondition>


class MeshWorker : public QThread
{
    Q_OBJECT

public:
    MeshWorker(QWaitCondition *p_waitToContinue)
        : p_waitToContinue(p_waitToContinue) {}

signals:
    void hasChangedMesh();

protected:
    virtual void run() = 0;

    void waitToContinue()
    {
        if (p_waitToContinue != NULL)
        {
            emit hasChangedMesh();
            waitMutex.lock();
            p_waitToContinue->wait(&waitMutex);
            waitMutex.unlock();
        }
    }

    QMutex waitMutex;
    QWaitCondition *p_waitToContinue;
};

#endif // MESHWORKER_H
