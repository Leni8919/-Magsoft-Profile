/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef MESHHANDLER_H
#define MESHHANDLER_H

#include <vector>
#include <QString>
#include <QMutex>

#include "GUI/window.h"

#include "MeshDecimater/meshDecimaterTraits.hpp"

#include "MeshDecimater/meshDecimater.hpp"
#include "MeshCompressor/MeshCompressor.hpp"
#include "MeshDecompressor/MeshDecompressor.hpp"


class MeshHandler : public QObject
{
    Q_OBJECT

public:
    MeshHandler(bool b_compression, bool b_gui,
                bool b_randomAccess);
    ~MeshHandler();

    void loadMesh(char *psz_filePath, unsigned i_nbQuantBits);

    DeciMesh *getDeciMesh() {return p_dmesh;}
    DeciMesh *getBaseMesh() {return p_bmesh;}

    void decimate();
    void compress();
    void decompress(set<DeciMesh::VertexHandle> selectedVertices);

    bool isInCompressionMode() {return b_compression;}

    friend class Window;

private:
    DeciMesh *p_dmesh;
    DeciMesh *p_bmesh;
    Window *p_window;

    QWaitCondition *p_waitToContinue;

    QString pathPrefix;

    /* Workers. */
    MeshDecimater *myMeshDecimater;
    MeshCompressor *myMeshCompressor;
    MeshDecompressor *myMeshDecompressor;

    bool b_compression;
    bool b_randomAccess;
};

#endif // MESHHANDLER_H
