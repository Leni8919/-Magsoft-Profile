/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <stdio.h>
#include <sys/time.h>
#include <OpenMesh/Core/IO/MeshIO.hh>

#include <QMutex>

#include "MeshHandler.h"
#include "GUI/window.h"


MeshHandler::MeshHandler(bool b_compression, bool b_gui,
                         bool b_randomAccess)
    : p_dmesh(NULL), p_bmesh(NULL),
      b_compression(b_compression), b_randomAccess(b_randomAccess)
{
    p_waitToContinue = b_gui ? new QWaitCondition() : NULL;

    // Initialize the workers.
    myMeshDecimater = new MeshDecimater(p_waitToContinue);
    myMeshCompressor = new MeshCompressor(p_waitToContinue, b_randomAccess);
    myMeshDecompressor = new MeshDecompressor(p_waitToContinue);
}


MeshHandler::~MeshHandler()
{
    // Free the workers.
    delete myMeshDecimater;
    delete myMeshCompressor;
    delete myMeshDecompressor;

    delete p_dmesh;
    delete p_bmesh;
}


/**
  * Load a compressed mesh or a mesh to compress.
  * @param psz_filePath the path to the mesh file.
  * @param i_nbQuantBits the number of quantization bits for a mesh to compress.
  */
void MeshHandler::loadMesh(char *psz_filePath, unsigned i_nbQuantBits)
{
    // Load a mesh that can be compressed.
    p_dmesh = new DeciMesh();

    if (b_compression)
    {
        if (!OpenMesh::IO::read_mesh(*p_dmesh, psz_filePath))
        {
            printf( "Error: Could not read mesh from %s.\n", psz_filePath );
            return;
        }

        printf(" -> Compute the bounding box.\n");
        p_dmesh->i_nbQuantBits = i_nbQuantBits;
        p_dmesh->updateBoundingBox();

        printf(" -> Computing face and vertex normals.\n");
        p_dmesh->request_face_normals();
        p_dmesh->request_vertex_normals();
        p_dmesh->update_normals();
    }
    else
    {
        myMeshDecompressor->setData(p_dmesh, psz_filePath);
        myMeshDecompressor->decompressGlobalLOD();
        // Save the base mesh.
        p_bmesh = new DeciMesh();
        *p_bmesh = *p_dmesh;
    }

    printf("Mesh to decimate loaded.\n");
    printf(" -> Nb Faces: %u\n", p_dmesh->n_faces());
    printf(" -> Nb vertices: %u\n", p_dmesh->n_vertices());
}


/**
  * Decimate a mesh to compress.
  */
void MeshHandler::decimate()
{
    assert(b_compression);
    myMeshDecimater->setData(p_dmesh);
    if (p_waitToContinue != NULL)
        myMeshDecimater->start();
    else
        myMeshDecimater->run();
}


/**
  * Compress a decimated mesh.
  */
void MeshHandler::compress()
{
    assert(b_compression);
    myMeshCompressor->setData(p_dmesh);
    if (p_waitToContinue != NULL)
        myMeshCompressor->start();
    else
        myMeshCompressor->run();
}


/**
  * Decompress the mesh.
  * The cluster vertices given in argument are fully decompressed.
  * @param selectedVertices the cluster vertices to fully decompress.
  */
void MeshHandler::decompress(set<DeciMesh::VertexHandle> selectedVertices)
{
    assert(!b_compression);
    *p_dmesh = *p_bmesh;
    myMeshDecompressor->setData(selectedVertices);
    myMeshDecompressor->start();
}
