/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef FRENETROTATION_H
#define FRENETROTATION_H

#include "MeshDecimater/meshDecimaterTraits.hpp"

// Double precision needed for the frenet rotation computations.
class Matrix
{
public:
    Matrix()
    {
        memset(c, 0, sizeof(c));
    }

    Matrix(double r0x, double r0y, double r0z,
           double r1x, double r1y, double r1z,
           double r2x, double r2y, double r2z)
    {
        c[0][0] = r0x, c[0][1] = r0y; c[0][2] = r0z;
        c[1][0] = r1x, c[1][1] = r1y; c[1][2] = r1z;
        c[2][0] = r2x, c[2][1] = r2y; c[2][2] = r2z;
    }

    Matrix& operator=(const Matrix &m)
    {
        for (unsigned i = 0; i < 3; ++i)
            for (unsigned j = 0; j < 3; ++j)
                c[i][j] = m.c[i][j];
        return *this;
    }

    Vec3d operator *(const Vec3d v)
    {
        return Vec3d(c[0][0] * v[0] + c[0][1] * v[1] + c[0][2] * v[2],
                     c[1][0] * v[0] + c[1][1] * v[1] + c[1][2] * v[2],
                     c[2][0] * v[0] + c[2][1] * v[1] + c[2][2] * v[2]);
    }

    Vec3d r0() const {return Vec3d(c[0][0], c[0][1], c[0][2]);}
    Vec3d r1() const {return Vec3d(c[1][0], c[1][1], c[1][2]);}
    Vec3d r2() const {return Vec3d(c[2][0], c[2][1], c[2][2]);}

private:
    double c[3][3];
};

void determineFrenetFrame(const DeciMesh::Point v1,
                          const DeciMesh::Point v2,
                          const Vec3f &normal,
                          Vec3f &t1, Vec3f &t2);
Vec3i frenetRotation(const Vec3i &Dist, const Vec3f &T1,
                     const Vec3f &T2, const Vec3f &normal);
Vec3i invFrenetRotation(const Vec3i &Frenet, const Vec3f &T1,
                        const Vec3f &T2, const Vec3f &normal);


#endif // FRENETROTATION_H
