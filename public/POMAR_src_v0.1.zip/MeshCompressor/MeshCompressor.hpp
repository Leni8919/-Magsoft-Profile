/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#ifndef MESHCOMPRESSOR_HPP
#define MESHCOMPRESSOR_HPP

#include <stdint.h>
#include <queue>

#include "Mesh/MeshWorker.h"
#include "MeshDecimater/meshDecimaterTraits.hpp"

#include "RangeCoder/rangecod.h"
#include "RangeCoder/qsmodel.h"

#include "Mesh/RankedHalfedge.hpp"

#define BUFFER_SIZE 50 * 1024 * 1024


class MeshCompressor : public MeshWorker
{
public:
    MeshCompressor(QWaitCondition *p_waitToContinue, bool b_randomAccess)
        : MeshWorker(p_waitToContinue),
          i_connectivitySize(0),
          i_geometrySize(0),
          filePathOutput("out.pomar"),
          b_randomAccess(b_randomAccess) { }

    void setData(DeciMesh *p_dmesh) {this->p_dmesh = p_dmesh;}
    void run();

private:
    bool canSplitVertex(PerformedOperation &op);
    void vertexSplit(PerformedOperation &op);
    void determineNbNonClusteredLOD(float p);

    // Code generation.
    void generateCodes();
    void generateCodesFirstLOD();
    void generateCodesNormalLOD();
    void codeVertexSplit(unsigned i_clusterId,
                         DeciMesh::HalfedgeHandle heh,
                         PerformedOperation &op);
    unsigned rankPivotLeft(DeciMesh::HalfedgeHandle heh,
                           PerformedOperation &op);
    unsigned rankPivotRight(DeciMesh::HalfedgeHandle heh,
                            PerformedOperation &op);
    unsigned encodePivotVertices(DeciMesh::HalfedgeHandle heh,
                                 PerformedOperation &op);

    // Compression
    void initBuffersAndRangeCoders();
    void determineCoderValues();
    void initAndEncodeModels(unsigned i_clusterId);
    void compressCluster(unsigned i_clusterId);
    void deleteModels();
    void deleteBuffers();

    // Output
    DeciMesh::HalfedgeHandle writeHeaderAndBaseMesh();
    void writeClusterSizes();
    void writeBits(uint32_t data, unsigned i_nbBits, char *p_dest,
                   unsigned &i_bitOffset, size_t &offset);
    void writeFloat(float f);
    void writeUInt8(uint8_t i);
    void writeInt16(int16_t i);
    int writeCompressedFile();

    DeciMesh *p_dmesh;

    vector<deque<unsigned> > nbSplitSymbols;
    vector<deque<unsigned> > nbSkipsHehSymbols;
    vector<deque<unsigned> > vertexSplitSymbols;
    vector<deque<int> > geometrySymbols;
    vector<deque<int> > geometryNormalSymbols;

    vector<unsigned> maxNbSplits;
    vector<unsigned> maxNbSkips;
    vector<unsigned> maxVertexSplits;
    vector<int> minResiduals;
    vector<unsigned> residualRanges;
    vector<int> minResidualNormals;
    vector<unsigned> residualNormalRanges;

    unsigned i_nbBitsNbSplits;
    unsigned i_nbBitsNbSkips;
    unsigned i_nbBitsVertexSplits;
    unsigned i_nbBitsMinResidual;
    unsigned i_nbBitsResidualRange;
    unsigned i_nbBitsMinResidualNormal;
    unsigned i_nbBitsResidualNormalRange;

    int i_minMinResidual;
    int i_minMinResidualNormal;

    unsigned i_nbLODs;

    rangecoder rangeCoder, rangeCoderMes;

    qsmodel nbSkipsHehSymbolsModel, vertexSplitSymbolsModel,
            nbSplitSymbolsModel,
            geometrySymbolsModel, geometryNormalSymbolsModel;

    char *p_data, *p_dataMes, *p_dataClusters;
    size_t *p_dataOffset, *p_dataOffsetMes, *p_dataOffsetClusters;

    size_t i_connectivitySize;
    size_t i_geometrySize;

    unsigned i_maxNbSplits;
    unsigned i_maxNbSkipsHehSymbol;
    unsigned i_maxVertexSplits;
    int i_minResidual;
    int i_maxResidual;
    int i_minResidualNormal;
    int i_maxResidualNormal;

    QString filePathOutput;

    bool b_randomAccess;
};

#endif // MESHCOMPRESSOR_HPP
