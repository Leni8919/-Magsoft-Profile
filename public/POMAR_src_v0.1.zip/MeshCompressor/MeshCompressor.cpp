/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/IO/reader/OFFReader.hh>
#include <OpenMesh/Core/IO/writer/OFFWriter.hh>

#include "MeshCompressor.hpp"
#include "FrenetRotation/frenetRotation.h"

#include <iomanip>
#include <queue>


/**
  * Run the mesh compression.
  */
void MeshCompressor::run()
{
    cout << "Quantize the vertices positions." << endl;

    p_dmesh->quantizeVertexPositions();

    cout << "Write the base mesh and the headers." << endl;

    initBuffersAndRangeCoders();

    i_nbLODs = p_dmesh->performedOperations.size();
    determineNbNonClusteredLOD(0.03);

    const DeciMesh::HalfedgeHandle heh_first = writeHeaderAndBaseMesh();

    cout << "Begining of the mesh reconstruction." << endl;

    p_dmesh->i_nbClusters = 1;
    unsigned i_minClusterId = 0;
    p_dmesh->clusterSeedHeh.push_back(heh_first);

    nbSkipsHehSymbols.resize(1);
    vertexSplitSymbols.resize(1);
    geometrySymbols.resize(1);
    geometryNormalSymbols.resize(1);
    nbSplitSymbols.resize(1);

    unsigned i_curNbVertices = p_dmesh->i_nbVerticesBaseMesh;

    for (unsigned i_LODrev = 0; i_LODrev < i_nbLODs; ++i_LODrev)
    {
        // Start the cluster compression when needed.
        if (i_LODrev == p_dmesh->i_nbGlobalLOD)
        {
            // Assign the ids and the seed halfedges for each cluster.
            p_dmesh->numberClusters();
            i_minClusterId = 1;

            nbSkipsHehSymbols.resize(p_dmesh->i_nbClusters);
            vertexSplitSymbols.resize(p_dmesh->i_nbClusters);
            geometrySymbols.resize(p_dmesh->i_nbClusters);
            geometryNormalSymbols.resize(p_dmesh->i_nbClusters);
            nbSplitSymbols.resize(p_dmesh->i_nbClusters);

            p_dmesh->clusterSizes.resize(p_dmesh->i_nbClusters);

            waitToContinue();
        }


        unsigned i_LOD = i_nbLODs - 1 - i_LODrev;

        cout << "Reconstructing level n°" << i_LODrev + 1 << "/" << i_nbLODs << "." << endl;

        std::queue<PerformedOperation> opToPerform;

        for (DeciMesh::ConstVertexIter v_it = p_dmesh->vertices_begin();
             v_it  != p_dmesh->vertices_end(); ++v_it)
            p_dmesh->data(v_it).b_conquered = false;

        for (DeciMesh::ConstHalfedgeIter h_it = p_dmesh->halfedges_begin();
             h_it != p_dmesh->halfedges_end(); ++h_it)
            p_dmesh->data(h_it).b_dontCount = false;

        for (unsigned i_clusterId = i_minClusterId;
             i_clusterId < p_dmesh->i_nbClusters; ++i_clusterId)
        {
            queue<DeciMesh::HalfedgeHandle> hehQueue;

            hehQueue.push(p_dmesh->clusterSeedHeh[i_clusterId]);

            while (!hehQueue.empty())
            {
                const DeciMesh::HalfedgeHandle hehEntry = hehQueue.front();
                hehQueue.pop();

                const DeciMesh::VertexHandle vhTo = p_dmesh->to_vertex_handle(hehEntry);

                if (p_dmesh->data(vhTo).i_clusterId != i_clusterId
                    || p_dmesh->data(vhTo).b_conquered)
                    continue;

                // Rank the candidate halfedges.
                priority_queue<RankedHalfedge> rankedHeh;

                DeciMesh::HalfedgeHandle hehIt = hehEntry;
                do
                {
                    hehIt = p_dmesh->next_halfedge_handle(hehIt);
                    hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
                    rankedHeh.push(RankedHalfedge(p_dmesh, hehIt));
                }
                while (hehIt != hehEntry);

                // Code the needed splits.
                PerformedOperationMap::iterator itLow = p_dmesh->performedOperations[i_LOD].lower_bound(vhTo);
                PerformedOperationMap::iterator itUp = p_dmesh->performedOperations[i_LOD].upper_bound(vhTo);

                unsigned i_nbSplits = 0;
                unsigned i_nbSkipsHeh = 0;
                while (!rankedHeh.empty())
                {
                    RankedHalfedge rh = rankedHeh.top();
                    rankedHeh.pop();

                    if (p_dmesh->data(rh.heh).b_dontCount)
                        continue;

                    const DeciMesh::VertexHandle vhFrom = p_dmesh->from_vertex_handle(rh.heh);

                    // Test if there is no need to code this halfedge.
                    bool b_hasSplit = false;
                    for (PerformedOperationMap::iterator it = itLow; it != itUp; ++it)
                    {
                        PerformedOperation op = it->second;
                        if (op.v2 == vhFrom)
                        {
                            //assert(canSplitVertex(op));
                            opToPerform.push(op);

                            // Code the operation.
                            codeVertexSplit(i_clusterId, rh.heh, op);

                            b_hasSplit = true;
                        }
                    }

                    if (b_hasSplit)
                    {
                        nbSkipsHehSymbols[i_clusterId].push_back(i_nbSkipsHeh);
                        i_nbSkipsHeh = 0;
                        i_nbSplits++;
                    }
                    else
                        i_nbSkipsHeh++;
                }

                // Code the number of vertex splits for this vertex.
                nbSplitSymbols[i_clusterId].push_back(i_nbSplits);

                // Mark it as conquered.
                p_dmesh->data(vhTo).b_conquered = true;

                // Add neighboring halfedges to que queue.
                const DeciMesh::HalfedgeHandle hehEntryOpp = p_dmesh->opposite_halfedge_handle(hehEntry);
                hehIt = hehEntryOpp;
                do
                {
                    hehIt = p_dmesh->prev_halfedge_handle(hehIt);
                    hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
                    hehQueue.push(hehIt);
                }
                while (hehIt != hehEntryOpp);
            }
        }

        assert(opToPerform.size() == p_dmesh->performedOperations[i_LOD].size());

        while (!opToPerform.empty())
        {
            PerformedOperation op = opToPerform.front();
            opToPerform.pop();
            vertexSplit(op);
            i_curNbVertices++;
        }

        // Free the memory occupied by this LOD performed operations.
        p_dmesh->performedOperations[i_LOD].clear();
    }

    // Determine the range coder values.
    determineCoderValues();

    cout << "Compressing the clusters." << endl;

    // Compress the global levels of details.
    compressCluster(0);

    if (b_randomAccess)
    {
        // Compress the cluster but store the compressed data in a separate buffer
        // because the cluster sizes will have first to be written in the general buffer.
        rangeCoder.p_data = p_dataClusters;
        rangeCoder.p_dataOffset = p_dataOffsetClusters;
        for (unsigned i_clusterId = 1; i_clusterId < p_dmesh->i_nbClusters; ++i_clusterId)
            compressCluster(i_clusterId);

        // Write the cluster sizes in the file buffer.
        writeClusterSizes();

        // Copy the cluster data into the main data buffer.
        memcpy(p_data + *p_dataOffset, p_dataClusters, *p_dataOffsetClusters);
        *p_dataOffset += *p_dataOffsetClusters;
    }

    // Write the compressed data to the output file.
    writeCompressedFile();

    cout << fixed << setprecision(2);
    cout << "Total connectivity: " << (float)i_connectivitySize / p_dmesh->n_vertices() << "\n";

    cout << "Total geometry: " << (float)i_geometrySize / p_dmesh->n_vertices() << "\n";

    cout << "Total: " << (float)(i_geometrySize + i_connectivitySize) / p_dmesh->n_vertices() << "\n";

    cout << "Number of clusters: " << p_dmesh->i_nbClusters - 1 << endl;

    cout << "Initial number of vertices: " << p_dmesh->n_vertices() << endl;

    deleteBuffers();

    emit hasChangedMesh();
}


#if 0
bool MeshCompressor::canSplitVertex(PerformedOperation &op)
{
    set<VertexHandle> v1Neighbors;

    for (DeciMesh::ConstVertexVertexIter vv_it = p_dmesh->cvv_iter(op.v1);
         vv_it; ++vv_it)
        v1Neighbors.insert(vv_it);

    for (set<VertexHandle>::iterator it = op.vrNeighborsBefore.begin();
         it != op.vrNeighborsBefore.end(); ++it)
        if (*it != op.v1 && v1Neighbors.count(*it) == 0)
            return false;

    return true;
}
#endif


/**
  * Split a vertex and update the modified neighbor face normals.
  */
void MeshCompressor::vertexSplit(PerformedOperation &op)
{
    p_dmesh->status(op.vr).set_deleted(false);
    p_dmesh->vertex_split(op.vr, op.v1, op.vhPivotL, op.vhPivotR);

    p_dmesh->data(op.vr).i_clusterId = p_dmesh->data(op.v1).i_clusterId;

    for (DeciMesh::ConstVertexFaceIter cvf_it = p_dmesh->cvf_iter(op.vr);
         cvf_it; ++cvf_it)
        p_dmesh->update_normal(cvf_it);

    // Checks
#if 0
    assert(op.vrNeighborsBefore.size() == p_dmesh->valence(op.vr));
    for (set<DeciMesh::VertexHandle>::iterator vhIt = op.vrNeighborsBefore.begin();
         vhIt != op.vrNeighborsBefore.end(); ++vhIt)
        assert(p_dmesh->areVerticesConnected(op.vr, *vhIt));
#endif
}


/**
  * Determine the number of non-clustered levels of details
  * @param p the min percentage of the vertices that will belong to the base clustered mesh.
  */
void MeshCompressor::determineNbNonClusteredLOD(float p)
{
    unsigned i_nbLOD = p_dmesh->performedOperations.size();
    unsigned i_totalNbVertices = p_dmesh->n_vertices();
    unsigned i_nbInsertedVertices = 0;

    if (b_randomAccess)
        for (unsigned i = 0; i < i_nbLOD; ++i)
        {
            i_nbInsertedVertices += p_dmesh->performedOperations[i_nbLOD - 1 - i].size();
            if ((float)i_nbInsertedVertices / i_totalNbVertices > p)
            {
                p_dmesh->i_nbGlobalLOD = i + 1;
                p_dmesh->i_nbClusteredLOD = i_nbLODs - p_dmesh->i_nbGlobalLOD;
                return;
            }
        }

    p_dmesh->i_nbGlobalLOD = i_nbLOD;
    p_dmesh->i_nbClusteredLOD = 0;
}
