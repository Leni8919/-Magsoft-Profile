/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "MeshCompressor.hpp"


/**
  * Init the compression buffers and the range coders.
  */
void MeshCompressor::initBuffersAndRangeCoders()
{
    p_data = new char[BUFFER_SIZE];
    p_dataMes = new char[BUFFER_SIZE];
    p_dataClusters = new char[BUFFER_SIZE];

    memset(p_data, 0, BUFFER_SIZE);
    memset(p_dataClusters, 0, BUFFER_SIZE);

    p_dataOffset = new size_t;
    p_dataOffsetMes = new size_t;
    p_dataOffsetClusters = new size_t;


    *p_dataOffset = 0;
    *p_dataOffsetMes = 0;
    *p_dataOffsetClusters = 0;

    rangeCoder.p_data = p_data;
    rangeCoderMes.p_data = p_dataMes;
    rangeCoder.p_dataOffset = p_dataOffset;
    rangeCoderMes.p_dataOffset = p_dataOffsetMes;
}


/**
  * Determine the minimum and range values for the range coder
  * models for all the clusters.
  */
void MeshCompressor::determineCoderValues()
{
    maxNbSplits.resize(p_dmesh->i_nbClusters);
    maxNbSkips.resize(p_dmesh->i_nbClusters);
    maxVertexSplits.resize(p_dmesh->i_nbClusters);
    minResiduals.resize(p_dmesh->i_nbClusters);
    residualRanges.resize(p_dmesh->i_nbClusters);
    minResidualNormals.resize(p_dmesh->i_nbClusters);
    residualNormalRanges.resize(p_dmesh->i_nbClusters);

    for (unsigned i_clusterId = 0; i_clusterId < p_dmesh->i_nbClusters;
         ++i_clusterId)
    {
        maxNbSplits[i_clusterId] = *max_element(nbSplitSymbols[i_clusterId].begin(),
                                                nbSplitSymbols[i_clusterId].end());

        if (maxNbSplits[i_clusterId] > 0)
        {
            maxNbSkips[i_clusterId] = *max_element(nbSkipsHehSymbols[i_clusterId].begin(),
                                                   nbSkipsHehSymbols[i_clusterId].end());
            maxVertexSplits[i_clusterId] = *max_element(vertexSplitSymbols[i_clusterId].begin(),
                                                        vertexSplitSymbols[i_clusterId].end());

            minResiduals[i_clusterId] = *min_element(geometrySymbols[i_clusterId].begin(),
                                                     geometrySymbols[i_clusterId].end());
            i_maxResidual = *max_element(geometrySymbols[i_clusterId].begin(),
                                         geometrySymbols[i_clusterId].end());
            residualRanges[i_clusterId] = i_maxResidual - minResiduals[i_clusterId] + 1;

            minResidualNormals[i_clusterId] = *min_element(geometryNormalSymbols[i_clusterId].begin(),
                                                           geometryNormalSymbols[i_clusterId].end());
            i_maxResidualNormal = *max_element(geometryNormalSymbols[i_clusterId].begin(),
                                               geometryNormalSymbols[i_clusterId].end());
            residualNormalRanges[i_clusterId] = i_maxResidualNormal - minResidualNormals[i_clusterId] + 1;
        }
    }

    i_nbBitsNbSplits = ceil(log(*max_element(maxNbSplits.begin() + 1, maxNbSplits.end()) + 1) / log(2));
    i_nbBitsNbSkips = ceil(log(*max_element(maxNbSkips.begin() + 1, maxNbSkips.end()) + 1) / log(2));
    i_nbBitsVertexSplits = ceil(log(*max_element(maxVertexSplits.begin() + 1,
                                                 maxVertexSplits.end()) + 1) / log(2));

    i_minMinResidual = *min_element(minResiduals.begin() + 1, minResiduals.end());
    i_nbBitsMinResidual = ceil(log(*max_element(minResiduals.begin() + 1, minResiduals.end())
                                   - i_minMinResidual + 1) / log(2));
    i_nbBitsResidualRange = ceil(log(*max_element(residualRanges.begin() + 1,
                                                  residualRanges.end()) + 1) / log(2));

    i_minMinResidualNormal = *min_element(minResidualNormals.begin() + 1, minResidualNormals.end());
    i_nbBitsMinResidualNormal = ceil(log(*max_element(minResidualNormals.begin() + 1, minResidualNormals.end())
                                         - i_minMinResidualNormal + 1) / log(2));
    i_nbBitsResidualNormalRange = ceil(log(*max_element(residualNormalRanges.begin() + 1,
                                                        residualNormalRanges.end()) + 1) / log(2));
}


/**
  * Init the range coders and models.
  * Encode the minimum and range value to comprss one cluster.
  * @param i_clusterId the cluster id.
  */
void MeshCompressor::initAndEncodeModels(unsigned i_clusterId)
{
    unsigned i_nbBits;

    i_maxNbSplits = maxNbSplits[i_clusterId];
    //cout << "Max nb splits: " << i_maxNbSplits << endl;
    initqsmodel(&nbSplitSymbolsModel, i_maxNbSplits + 1, 10, 1 << 9, NULL, 1);

    i_nbBits = i_clusterId > 0 ? i_nbBitsNbSplits : 3;
    assert(i_maxNbSplits < (unsigned)(1 << i_nbBits));
    encode_shift(&rangeCoder, 1, i_maxNbSplits, i_nbBits);

    i_maxNbSkipsHehSymbol = 0;
    i_maxVertexSplits = 0;
    i_minResidual = 0;
    i_minResidualNormal = 0;

    if (i_maxNbSplits > 0)
    {
        i_maxNbSkipsHehSymbol = maxNbSkips[i_clusterId];
        //cout << "Max Heh Symbol: " << i_maxNbSkipsHehSymbol << endl;
        initqsmodel(&nbSkipsHehSymbolsModel, i_maxNbSkipsHehSymbol + 1, 10, 1 << 9, NULL, 1);

        i_nbBits = i_clusterId > 0 ? i_nbBitsNbSkips : 4;
        assert(i_maxNbSkipsHehSymbol < (unsigned)(1 << i_nbBits));
        encode_shift(&rangeCoder, 1, i_maxNbSkipsHehSymbol, i_nbBits);


        i_maxVertexSplits = maxVertexSplits[i_clusterId];
        //cout << "Max vertex split symbol: " << i_maxVertexSplits << endl;
        initqsmodel(&vertexSplitSymbolsModel, i_maxVertexSplits + 1, 10, 1 << 9, NULL, 1);

        i_nbBits = i_clusterId > 0 ? i_nbBitsVertexSplits : 5;
        assert(i_maxVertexSplits < (unsigned)(1 << i_nbBits));
        encode_shift(&rangeCoder, 1, i_maxVertexSplits, i_nbBits);


        i_minResidual = minResiduals[i_clusterId];
        //cout << "Tangential components min: " << i_minResidual << " range: " << residualRanges[i_clusterId] << endl;
        initqsmodel(&geometrySymbolsModel, residualRanges[i_clusterId], 18, 1 << 17, NULL, 1);

        if (i_clusterId > 0)
        {
            assert(i_minResidual - i_minMinResidual < (1 << i_nbBitsMinResidual));
            encode_shift(&rangeCoder, 1, i_minResidual - i_minMinResidual, i_nbBitsMinResidual);
            encode_shift(&rangeCoderMes, 1, i_minResidual - i_minMinResidual, i_nbBitsMinResidual);
            assert(residualRanges[i_clusterId] < (unsigned)(1 << i_nbBitsResidualRange));
            encode_shift(&rangeCoder, 1, residualRanges[i_clusterId], i_nbBitsResidualRange);
            encode_shift(&rangeCoderMes, 1, residualRanges[i_clusterId], i_nbBitsResidualRange);
        }
        else
        {
            // Encode the min value and the range.
            int16_t i16_min;
            assert(i_minResidual >= -(1 << 14) && i_minResidual <= (1 << 14));
            i16_min = i_minResidual;
            encode_short(&rangeCoder, *(uint16_t *)&i16_min);
            encode_short(&rangeCoderMes, *(uint16_t *)&i16_min);
            unsigned i_range = residualRanges[i_clusterId];
            assert(i_range < (1 << 14));
            encode_short(&rangeCoder, i_range);
            encode_short(&rangeCoderMes, i_range);
        }


        i_minResidualNormal = minResidualNormals[i_clusterId];
        //cout << "Normal component min: " << i_minResidualNormal << " range: " << residualNormalRanges[i_clusterId] << endl;
        initqsmodel(&geometryNormalSymbolsModel, residualNormalRanges[i_clusterId], 18, 1 << 17, NULL, 1);

        if (i_clusterId > 0)
        {
            assert(i_minResidualNormal - i_minMinResidualNormal < (1 << i_nbBitsMinResidualNormal));
            encode_shift(&rangeCoder, 1, i_minResidualNormal - i_minMinResidualNormal, i_nbBitsMinResidualNormal);
            encode_shift(&rangeCoderMes, 1, i_minResidualNormal - i_minMinResidualNormal, i_nbBitsMinResidualNormal);
            assert(residualNormalRanges[i_clusterId] < (unsigned)(1 << i_nbBitsResidualNormalRange));
            encode_shift(&rangeCoder, 1, residualNormalRanges[i_clusterId], i_nbBitsResidualNormalRange);
            encode_shift(&rangeCoderMes, 1, residualNormalRanges[i_clusterId], i_nbBitsResidualNormalRange);
        }
        else
        {
            // Encode the min value and the range.
            int16_t i16_min;
            assert(i_minResidualNormal >= -(1 << 14) && i_minResidualNormal <= (1 << 14));
            i16_min = i_minResidualNormal;
            encode_short(&rangeCoder, *(uint16_t *)&i16_min);
            encode_short(&rangeCoderMes, *(uint16_t *)&i16_min);
            unsigned i_range = residualNormalRanges[i_clusterId];
            assert(i_range < (1 << 14));
            encode_short(&rangeCoder, i_range);
            encode_short(&rangeCoderMes, i_range);
        }
    }
}


/**
  * Compress the symbols of one cluster.
  * @param i_clusterId the id of the cluster.
  */
void MeshCompressor::compressCluster(unsigned i_clusterId)
{
    // Start the encoder.
    start_encoding(&rangeCoder, 0, 0);
    start_encoding(&rangeCoderMes, 0, 0);

    initAndEncodeModels(i_clusterId);

    unsigned i_len = nbSplitSymbols[i_clusterId].size();
    unsigned i_splitIndex = 0;
    for (unsigned i = 0; i < i_len; ++i)
    {
        unsigned i_nbSplits = nbSplitSymbols[i_clusterId][i];

        // Encode the nb splits symbol.
        int syfreq, ltfreq;
        qsgetfreq(&nbSplitSymbolsModel, i_nbSplits, &syfreq, &ltfreq);
        encode_shift(&rangeCoder, syfreq, ltfreq, 10);
        qsupdate(&nbSplitSymbolsModel, i_nbSplits);

        for (unsigned j = 0; j < i_nbSplits; ++j)
        {
            // Encode the number of halfedge skips.
            unsigned i_nbSkipsHehSymbol = nbSkipsHehSymbols[i_clusterId][i_splitIndex];
            qsgetfreq(&nbSkipsHehSymbolsModel, i_nbSkipsHehSymbol, &syfreq, &ltfreq);
            encode_shift(&rangeCoder, syfreq, ltfreq, 10);
            qsupdate(&nbSkipsHehSymbolsModel, i_nbSkipsHehSymbol);

            // Encode the vertex split symbols.
            unsigned i_vertexSplitSymbol = vertexSplitSymbols[i_clusterId][2 * i_splitIndex];
            qsgetfreq(&vertexSplitSymbolsModel, i_vertexSplitSymbol, &syfreq, &ltfreq);
            encode_shift(&rangeCoder, syfreq, ltfreq, 10);
            qsupdate(&vertexSplitSymbolsModel, i_vertexSplitSymbol);

            i_vertexSplitSymbol = vertexSplitSymbols[i_clusterId][2 * i_splitIndex + 1];
            qsgetfreq(&vertexSplitSymbolsModel, i_vertexSplitSymbol, &syfreq, &ltfreq);
            encode_shift(&rangeCoder, syfreq, ltfreq, 10);
            qsupdate(&vertexSplitSymbolsModel, i_vertexSplitSymbol);

            // Encode the geometry tangential components.
            unsigned i_geomTangentialSymbol = geometrySymbols[i_clusterId][2 * i_splitIndex]
                                              - i_minResidual;
            assert(i_geomTangentialSymbol < residualRanges[i_clusterId]);
            qsgetfreq(&geometrySymbolsModel, i_geomTangentialSymbol, &syfreq, &ltfreq);
            encode_shift(&rangeCoder, syfreq, ltfreq, 18);
            encode_shift(&rangeCoderMes, syfreq, ltfreq, 18);
            qsupdate(&geometrySymbolsModel, i_geomTangentialSymbol);

            i_geomTangentialSymbol = geometrySymbols[i_clusterId][2 * i_splitIndex + 1]
                                     - i_minResidual;
            assert(i_geomTangentialSymbol < residualRanges[i_clusterId]);
            qsgetfreq(&geometrySymbolsModel, i_geomTangentialSymbol, &syfreq, &ltfreq);
            encode_shift(&rangeCoder, syfreq, ltfreq, 18);
            encode_shift(&rangeCoderMes, syfreq, ltfreq, 18);
            qsupdate(&geometrySymbolsModel, i_geomTangentialSymbol);

            // Encode the geometry normal component.
            unsigned i_geomNormalSymbol = geometryNormalSymbols[i_clusterId][i_splitIndex]
                                          - i_minResidualNormal;
            assert(i_geomNormalSymbol < residualNormalRanges[i_clusterId]);
            qsgetfreq(&geometryNormalSymbolsModel, i_geomNormalSymbol, &syfreq, &ltfreq);
            encode_shift(&rangeCoder, syfreq, ltfreq, 18);
            encode_shift(&rangeCoderMes, syfreq, ltfreq, 18);
            qsupdate(&geometryNormalSymbolsModel, i_geomNormalSymbol);

            i_splitIndex++;
        }
    }

    unsigned i_size = done_encoding(&rangeCoder);
    unsigned i_sizeGeom = done_encoding(&rangeCoderMes);

    //cout << "Cluster size: " << i_size << endl;
    p_dmesh->clusterSizes[i_clusterId] = i_size;

    i_connectivitySize += (i_size - i_sizeGeom) * 8;
    i_geometrySize += i_sizeGeom * 8;

    deleteModels();
}


/**
  * Delete the range coder models.
  */
void MeshCompressor::deleteModels()
{
    deleteqsmodel(&nbSplitSymbolsModel);
    if (i_maxNbSplits > 0)
    {
        deleteqsmodel(&nbSkipsHehSymbolsModel);
        deleteqsmodel(&vertexSplitSymbolsModel);
        deleteqsmodel(&geometrySymbolsModel);
        deleteqsmodel(&geometryNormalSymbolsModel);
    }
}


/**
  * Delete the buffers.
  */
void MeshCompressor::deleteBuffers()
{
    delete[] p_data;
    delete[] p_dataMes;
    delete[] p_dataClusters;

    delete p_dataOffset;
    delete p_dataOffsetMes;
    delete p_dataOffsetClusters;
}
