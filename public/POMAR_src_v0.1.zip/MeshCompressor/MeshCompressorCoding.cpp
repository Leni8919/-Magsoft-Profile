/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "MeshCompressor.hpp"
#include "FrenetRotation/frenetRotation.h"

#include <queue>


/**
  * Code a vertex split operation.
  * @param heh the halfedge handle to plit.
  * @param op a reference on the performed operation data structure.
  */
void MeshCompressor::codeVertexSplit(unsigned i_clusterId,
                                     DeciMesh::HalfedgeHandle heh,
                                     PerformedOperation &op)
{
    assert(op.v1 == p_dmesh->to_vertex_handle(heh));

    list<DeciMesh::VertexHandle> vrNeighborsBefore;
    vrNeighborsBefore.push_back(op.v2);
    vrNeighborsBefore.push_back(op.v1);

    unsigned symb[2];
    symb[0] = 0;
    DeciMesh::HalfedgeHandle hehIt = heh;
    while (p_dmesh->from_vertex_handle(hehIt) != op.vhPivotL)
    {
        hehIt = p_dmesh->next_halfedge_handle(hehIt);
        hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
        vrNeighborsBefore.push_back(p_dmesh->from_vertex_handle(hehIt));
        symb[0]++;
    }
    symb[0]--;

    symb[1] = 0;
    hehIt = p_dmesh->opposite_halfedge_handle(heh);
    while (p_dmesh->to_vertex_handle(hehIt) != op.vhPivotR)
    {
        hehIt = p_dmesh->prev_halfedge_handle(hehIt);
        hehIt = p_dmesh->opposite_halfedge_handle(hehIt);
        vrNeighborsBefore.push_back(p_dmesh->to_vertex_handle(hehIt));
        symb[1]++;
    }
    symb[1]--;

    vertexSplitSymbols[i_clusterId].push_back(symb[0]);
    vertexSplitSymbols[i_clusterId].push_back(symb[1]);

    // Compute the barycenter.
    Vec3f barycenter(0,0,0);
    for (list<VertexHandle>::iterator it = vrNeighborsBefore.begin();
         it != vrNeighborsBefore.end(); ++it)
        barycenter = barycenter + p_dmesh->point(*it);
    barycenter = barycenter / vrNeighborsBefore.size();

    // Compute the normal.
    const Vec3f normal = (p_dmesh->calc_face_normal(p_dmesh->face_handle(heh))
                          + p_dmesh->calc_face_normal(p_dmesh->face_handle(p_dmesh->opposite_halfedge_handle(heh)))).normalize_cond();

    Vec3i predPos = p_dmesh->floatPosToInt(barycenter);
    Vec3i vrPos = p_dmesh->floatPosToInt(p_dmesh->point(op.vr));
    Vec3i residual = vrPos - predPos;

    {
        Vec3f t1, t2;
        determineFrenetFrame(p_dmesh->point(op.v1), p_dmesh->point(op.v2), normal, t1, t2);
        Vec3i toEncode = frenetRotation(residual, t1, t2, normal);

        geometrySymbols[i_clusterId].push_back(toEncode[0]);
        geometrySymbols[i_clusterId].push_back(toEncode[1]);
        geometryNormalSymbols[i_clusterId].push_back(toEncode[2]);
    }

    p_dmesh->markEdgesToNotCount(i_clusterId, op);
}
