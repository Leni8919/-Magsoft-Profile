/*****************************************************************************
* Copyright (C) 2013 Adrien Maglo
*
* This file is part of POMAR.
*
* POMAR is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* POMAR is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with POMAR.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include "MeshCompressor.hpp"

#include <fstream>
#include <map>


/**
  * Write the file header and the base mesh.
  * @return the reference halfedge handle for the global LOD.
  */
DeciMesh::HalfedgeHandle MeshCompressor::writeHeaderAndBaseMesh()
{
    cout << "Writing the header and the base mesh." << endl;

    // Write the codec version.
    writeUInt8(1);
    i_connectivitySize += 8;

    // Write the bounding box min coordinate.
    for (unsigned i = 0; i < 3; ++i)
        writeFloat(p_dmesh->bbMin[i]);
    // Write the quantization step.
    writeFloat(p_dmesh->f_quantStep);

    i_geometrySize += 4 * sizeof(float) * 8;

    unsigned i_nbVerticesBaseMesh = p_dmesh->i_nbVerticesBaseMesh;
    unsigned i_nbFacesBaseMesh = 0;
    for (DeciMesh::ConstFaceIter f_it = p_dmesh->faces_begin();
         f_it != p_dmesh->faces_end(); ++f_it)
        if (!p_dmesh->status(f_it).deleted())
            i_nbFacesBaseMesh++;
    unsigned i_nbBitsPerVertex = ceil(log(i_nbVerticesBaseMesh) / log(2));

    unsigned i_bitOffset = 0;
    (*p_dataOffset)++;

    // Write the geometry quantization of the mesh.
    assert(p_dmesh->i_nbQuantBits - 1 < 1 << 4);
    writeBits(p_dmesh->i_nbQuantBits - 1, 4, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_geometrySize += 4;

    // Write the number of vertices and faces on 16 bits.
    cout << "Base mesh: " << i_nbVerticesBaseMesh << " vertices and " << i_nbFacesBaseMesh << " faces." << endl;
    writeBits(i_nbVerticesBaseMesh, 16, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    writeBits(i_nbFacesBaseMesh, 16, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_connectivitySize += 32;

    // Write the vertices.
    unsigned i_id = 0;
    map<DeciMesh::VertexHandle, unsigned> vertexMap;
    for (DeciMesh::ConstVertexIter v_it = p_dmesh->vertices_begin();
         v_it != p_dmesh->vertices_end(); ++v_it)
    {
        if (p_dmesh->status(v_it).deleted())
            continue;

        Vec3i p = p_dmesh->getQuantPos(v_it);

        // Write the coordinates.
        for (unsigned i = 0; i < 3; ++i)
        {
            assert(p[i] < 1 << p_dmesh->i_nbQuantBits);
            writeBits(p[i], p_dmesh->i_nbQuantBits, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
        }
        vertexMap[v_it] = i_id++;
    }
    i_geometrySize += i_nbVerticesBaseMesh * 3 * p_dmesh->i_nbQuantBits;

    // Write the base mesh face vertex indices.
    DeciMesh::HalfedgeHandle heh_first;
    bool b_firstFace = true;
    for (DeciMesh::ConstFaceIter f_it = p_dmesh->faces_begin();
         f_it != p_dmesh->faces_end(); ++f_it)
    {
        if (p_dmesh->status(f_it).deleted())
            continue;

        if (b_firstFace)
        {
            heh_first = p_dmesh->cfh_iter(f_it);
            b_firstFace = false;
        }

        for (DeciMesh::ConstFaceHalfedgeIter fh_it = p_dmesh->cfh_iter(f_it);
             fh_it; ++fh_it)
            writeBits(vertexMap[p_dmesh->from_vertex_handle(fh_it)], i_nbBitsPerVertex,
                      p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);

        i_connectivitySize += i_nbBitsPerVertex * 3;
    }

    // Write the number of global LOD and clustered LOD.
    assert((int)p_dmesh->i_nbGlobalLOD < 1 << 6);
    writeBits(p_dmesh->i_nbGlobalLOD, 6, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);

    assert((int)p_dmesh->i_nbClusteredLOD < 1 << 6);
    writeBits(p_dmesh->i_nbClusteredLOD, 6, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);

    i_connectivitySize += 12;

    if(i_bitOffset == 0)
        (*p_dataOffset)--;

    return heh_first;
}


/**
  * Write the cluster sizes in the data buffer.
  */
void MeshCompressor::writeClusterSizes()
{
    // Determine the max size of the clusters.
    unsigned i_maxSize = *max_element(++(p_dmesh->clusterSizes.begin()),
                                      p_dmesh->clusterSizes.end());

    // Determine the number of bits needed to write the cluster sizes.
    unsigned i_nbBitsPerClusterSize = ceil(log(i_maxSize + 1) / log(2));

    unsigned i_bitOffset = 0;
    (*p_dataOffset)++;

    // Write the number of bits.
    assert(i_nbBitsPerClusterSize < 1 << 4);
    writeBits(i_nbBitsPerClusterSize, 4, p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    i_connectivitySize += 4;

    for (unsigned i_clusterId = 1; i_clusterId < p_dmesh->i_nbClusters;
         ++i_clusterId)
    {
        assert((int)p_dmesh->clusterSizes[i_clusterId] < 1 << i_nbBitsPerClusterSize);
        writeBits(p_dmesh->clusterSizes[i_clusterId], i_nbBitsPerClusterSize,
                  p_data + *p_dataOffset - 1, i_bitOffset, *p_dataOffset);
    }
    i_connectivitySize += (p_dmesh->i_nbClusters - 1) * i_nbBitsPerClusterSize;

    // Write the number of bits used to code the range values for the clusters.

    assert(i_nbBitsNbSplits < 1 << 3);
    writeBits(i_nbBitsNbSplits, 3, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    assert(i_nbBitsNbSkips < 1 << 3);
    writeBits(i_nbBitsNbSkips, 3, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    assert(i_nbBitsVertexSplits < 1 << 3);
    writeBits(i_nbBitsVertexSplits, 3, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    assert(i_nbBitsMinResidual < 1 << 5);
    writeBits(i_nbBitsMinResidual, 5, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    assert(i_nbBitsResidualRange < 1 << 5);
    writeBits(i_nbBitsResidualRange, 5, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    assert(i_nbBitsMinResidualNormal < 1 << 5);
    writeBits(i_nbBitsMinResidualNormal, 5, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    assert(i_nbBitsResidualNormalRange < 1 << 5);
    writeBits(i_nbBitsResidualNormalRange, 5, p_data + *p_dataOffset - 1,
              i_bitOffset, *p_dataOffset);

    if(i_bitOffset == 0)
        (*p_dataOffset)--;

    // Write the min values of the geometry residual for the clusters.
    assert(i_minMinResidual > -(1 << 15));
    writeInt16(i_minMinResidual);

    assert(i_minMinResidualNormal > -(1 << 15));
    writeInt16(i_minMinResidualNormal);
}


/**
  * Write a given number of bits in a buffer.
  */
void MeshCompressor::writeBits(uint32_t data, unsigned i_nbBits, char *p_dest,
                               unsigned &i_bitOffset, size_t &offset)
{
    assert(i_nbBits <= 25);

    uint32_t dataToAdd = data << (32 - i_nbBits - i_bitOffset);
    // Swap the integer bytes because the x86 architecture is little endian.
    dataToAdd = __builtin_bswap32(dataToAdd); // Call a GCC builtin function.

    // Write the data.
    *(uint32_t *)p_dest |= dataToAdd;

    // Update the size and offset.
    offset += (i_bitOffset + i_nbBits) / 8;
    i_bitOffset = (i_bitOffset + i_nbBits) % 8;
}


/**
  * Write a floating point number in the data buffer.
  */
void MeshCompressor::writeFloat(float f)
{
    *(float *)(p_data + *p_dataOffset) = f;
    *p_dataOffset += sizeof(float);
}


/**
  * Write a 8-bits unsigned integer.
  */
void MeshCompressor::writeUInt8(uint8_t i)
{
    *(uint8_t *)(p_data + *p_dataOffset) = i;
    *p_dataOffset += sizeof(uint8_t);
}


/**
  * Write a 16-bits signed integer.
  */
void MeshCompressor::writeInt16(int16_t i)
{
    *(int16_t *)(p_data + *p_dataOffset) = i;
    *p_dataOffset += sizeof(int16_t);
}


/**
  * Write the compressed file.
  */
int MeshCompressor::writeCompressedFile()
{
    int i_ret = 1;

    std::cout << "Write the compressed file " << filePathOutput.toUtf8().data() << "." << std::endl;

    filebuf fb;
    fb.open(filePathOutput.toUtf8().data(), ios::out | ios::trunc);

    if (fb.is_open())
    {
        if (fb.sputn(p_data, *p_dataOffset) == (std::streamsize)*p_dataOffset)
            i_ret = 0;
        fb.close();
    }

    return i_ret;
}
